import { Platform, Share } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Block, ChartBlock, DrawingBlock, Note, TableBlock, TextBlock } from '../types';
import { escapeHtml, tocEntries, wordStats } from './utils';
import { calligraphyPath, smoothLine } from './draw';
import { renderEquation } from './equation';

const STYLE_HTML: Record<string, { size: number; weight: number; color?: string; mt: number; mb: number }> = {
  title: { size: 32, weight: 800, mt: 4, mb: 14 },
  h1: { size: 27, weight: 800, mt: 20, mb: 8 },
  h2: { size: 23, weight: 700, mt: 16, mb: 6 },
  h3: { size: 20, weight: 700, mt: 14, mb: 5 },
  h4: { size: 17, weight: 600, mt: 12, mb: 4 },
  h5: { size: 15, weight: 600, mt: 10, mb: 4 },
  h6: { size: 13, weight: 700, mt: 10, mb: 4 },
  normal: { size: 16, weight: 400, mt: 2, mb: 2 },
};

function textBlockHtml(b: TextBlock, listNumber: number): string {
  const st = STYLE_HTML[b.style] || STYLE_HTML.normal;
  const size = b.fontSize || st.size;
  const deco: string[] = [];
  if (b.underline) deco.push('underline');
  if (b.strike) deco.push('line-through');
  const styles = [
    `font-size:${size}px`,
    `font-weight:${b.bold ? 700 : st.weight}`,
    `margin-top:${b.spaceBefore ? st.mt + 14 : st.mt}px`,
    `margin-bottom:${b.spaceAfter ? st.mb + 14 : st.mb}px`,
    `text-align:${b.align}`,
    `padding-left:${b.indent * 28}px`,
    'line-height:1.55',
  ];
  if (b.italic) styles.push('font-style:italic');
  if (deco.length) styles.push(`text-decoration:${deco.join(' ')}`);
  if (b.color) styles.push(`color:${b.color}`);
  if (b.style === 'h6') styles.push('text-transform:uppercase;letter-spacing:1.5px');
  let content = escapeHtml(b.text);
  if (b.highlight) content = `<span style="background-color:${b.highlight};padding:0 3px;border-radius:3px">${content}</span>`;
  for (const l of b.links || []) {
    const label = escapeHtml(b.text.slice(l.start, l.end));
    if (label) content = content.replace(label, `<a href="${escapeHtml(l.url)}" style="color:#7C4DFF;text-decoration:underline">${label}</a>`);
  }
  let prefix = '';
  if (b.list === 'bullet') prefix = `<span style="color:#7C4DFF;font-weight:700;margin-right:10px">\u2022</span>`;
  if (b.list === 'number') prefix = `<span style="color:#7C4DFF;font-weight:700;margin-right:10px">${listNumber}.</span>`;
  const tag = b.style === 'normal' ? 'p' : b.style === 'title' ? 'h1' : b.style;
  return `<${tag} style="${styles.join(';')}">${prefix}${content}</${tag}>`;
}

function drawingSvg(b: DrawingBlock, width = 620): string {
  const H = Math.round(width * b.aspect);
  const parts: string[] = [];
  for (const p of b.paths) {
    const pts = p.points.map(q => ({ x: q.x * width, y: q.y * H }));
    const w = Math.max(0.5, p.width * width);
    if (p.tool === 'calligraphy') {
      parts.push(`<path d="${calligraphyPath(pts, w)}" fill="${p.color}"/>`);
    } else {
      const op = p.tool === 'highlighter' ? ' stroke-opacity="0.35"' : '';
      parts.push(`<path d="${smoothLine(pts)}" fill="none" stroke="${p.color}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"${op}/>`);
    }
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${H}" viewBox="0 0 ${width} ${H}" style="max-width:100%;background:transparent">${parts.join('')}</svg>`;
}

function chartSvg(b: ChartBlock, W = 620, H = 300): string {
  const data = b.data.filter(d => isFinite(d.value));
  if (!data.length) return '';
  const padL = 16, padB = 30, padT = 26;
  const parts: string[] = [];
  const font = "font-family='-apple-system,Segoe UI,Roboto,sans-serif'";
  if (b.chartType === 'pie') {
    const total = data.reduce((s, d) => s + Math.max(0, d.value), 0) || 1;
    const cx = H / 2, cy = H / 2, r = H / 2 - 30;
    let angle = -Math.PI / 2;
    data.forEach((d) => {
      const frac = Math.max(0, d.value) / total;
      const a2 = angle + frac * Math.PI * 2;
      const large = a2 - angle > Math.PI ? 1 : 0;
      const x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
      const x2 = cx + r * Math.cos(a2), y2 = cy + r * Math.sin(a2);
      if (frac > 0.999) {
        parts.push(`<circle cx='${cx}' cy='${cy}' r='${r}' fill='${d.color}'/>`);
      } else if (frac > 0) {
        parts.push(`<path d='M ${cx} ${cy} L ${x1.toFixed(1)} ${y1.toFixed(1)} A ${r} ${r} 0 ${large} 1 ${x2.toFixed(1)} ${y2.toFixed(1)} Z' fill='${d.color}'/>`);
      }
      const lx = H + 16;
      const ly = 40 + data.indexOf(d) * 24;
      parts.push(`<rect x='${lx}' y='${ly - 10}' width='12' height='12' rx='4' fill='${d.color}'/>`);
      parts.push(`<text x='${lx + 20}' y='${ly}' font-size='13' fill='#444' ${font}>${escapeHtml(d.label)} (${d.value})</text>`);
      angle = a2;
    });
  } else if (b.chartType === 'bar') {
    const max = Math.max(...data.map(d => d.value), 1);
    const n = data.length;
    const slot = (W - padL * 2) / n;
    const bw = Math.min(64, slot * 0.55);
    data.forEach((d, i) => {
      const bh = Math.max(2, ((H - padT - padB) * d.value) / max);
      const x = padL + slot * i + (slot - bw) / 2;
      const y = H - padB - bh;
      parts.push(`<rect x='${x.toFixed(1)}' y='${y.toFixed(1)}' width='${bw}' height='${bh.toFixed(1)}' rx='8' fill='${d.color}'/>`);
      parts.push(`<text x='${(x + bw / 2).toFixed(1)}' y='${(y - 8).toFixed(1)}' font-size='13' font-weight='600' text-anchor='middle' fill='#333' ${font}>${d.value}</text>`);
      parts.push(`<text x='${(x + bw / 2).toFixed(1)}' y='${H - 8}' font-size='12' text-anchor='middle' fill='#777' ${font}>${escapeHtml(d.label)}</text>`);
    });
    parts.push(`<line x1='${padL}' y1='${H - padB}' x2='${W - padL}' y2='${H - padB}' stroke='#E3DDF2' stroke-width='1.5'/>`);
  } else {
    const max = Math.max(...data.map(d => d.value), 1);
    const n = data.length;
    const step = n > 1 ? (W - padL * 2) / (n - 1) : 0;
    const pts = data.map((d, i) => ({
      x: padL + step * i,
      y: H - padB - ((H - padT - padB) * d.value) / max,
    }));
    const line = smoothLine(pts);
    const area = `${line} L ${pts[pts.length - 1].x} ${H - padB} L ${pts[0].x} ${H - padB} Z`;
    parts.push(`<path d='${area}' fill='#7C4DFF' fill-opacity='0.10'/>`);
    parts.push(`<path d='${line}' fill='none' stroke='#7C4DFF' stroke-width='3' stroke-linecap='round'/>`);
    pts.forEach((p, i) => {
      parts.push(`<circle cx='${p.x.toFixed(1)}' cy='${p.y.toFixed(1)}' r='5' fill='${data[i].color}' stroke='#fff' stroke-width='2'/>`);
      parts.push(`<text x='${p.x.toFixed(1)}' y='${(p.y - 12).toFixed(1)}' font-size='12' font-weight='600' text-anchor='middle' fill='#333' ${font}>${data[i].value}</text>`);
      parts.push(`<text x='${p.x.toFixed(1)}' y='${H - 8}' font-size='12' text-anchor='middle' fill='#777' ${font}>${escapeHtml(data[i].label)}</text>`);
    });
    parts.push(`<line x1='${padL}' y1='${H - padB}' x2='${W - padL}' y2='${H - padB}' stroke='#E3DDF2' stroke-width='1.5'/>`);
  }
  return `<svg xmlns='http://www.w3.org/2000/svg' width='${W}' height='${H}' viewBox='0 0 ${W} ${H}' style='max-width:100%'>${parts.join('')}</svg>`;
}

function tableHtml(b: TableBlock): string {
  const rows = b.rows.map((r, ri) => {
    const cells = r.map(c => ri === 0
      ? `<th style="border:1px solid #E3DDF2;padding:8px 12px;background:#F0EBFE;font-weight:600;text-align:left">${escapeHtml(c)}</th>`
      : `<td style="border:1px solid #E3DDF2;padding:8px 12px">${escapeHtml(c)}</td>`).join('');
    return `<tr>${cells}</tr>`;
  }).join('');
  return `<table style="border-collapse:collapse;width:100%;margin:12px 0;font-size:14px">${rows}</table>`;
}

function tocHtml(note: Note): string {
  const entries = tocEntries(note.blocks);
  if (!entries.length) return '<p style="color:#999"><em>No headings yet</em></p>';
  const items = entries.map(e =>
    `<div style="padding-left:${e.level * 18}px;margin:3px 0"><span style="color:#7C4DFF">\u2022</span> ${escapeHtml(e.text)}</div>`).join('');
  return `<div style="border:1px solid #E3DDF2;border-radius:12px;padding:14px 18px;margin:12px 0"><div style="font-weight:700;margin-bottom:6px">Table of Contents</div>${items}</div>`;
}

function blocksHtml(note: Note): string {
  let num = 0;
  const out: string[] = [];
  for (const b of note.blocks) {
    if (b.type !== 'text' || b.list !== 'number') num = 0;
    switch (b.type) {
      case 'text': {
        const t = b as TextBlock;
        if (t.list === 'number') num += 1;
        out.push(textBlockHtml(t, num));
        break;
      }
      case 'image':
        out.push(`<figure style="margin:14px 0"><img src="${b.uri}" style="max-width:100%;border-radius:12px"/>${b.caption ? `<figcaption style="color:#888;font-size:12px;margin-top:4px">${escapeHtml(b.caption)}</figcaption>` : ''}</figure>`);
        break;
      case 'table': out.push(tableHtml(b)); break;
      case 'drawing': out.push(`<div style="margin:14px 0">${drawingSvg(b)}</div>`); break;
      case 'chart':
        out.push(`<div style="margin:14px 0">${b.title ? `<div style="font-weight:700;margin-bottom:6px">${escapeHtml(b.title)}</div>` : ''}${chartSvg(b)}</div>`);
        break;
      case 'divider': out.push('<hr style="border:none;border-top:2px solid #E3DDF2;margin:20px 0"/>'); break;
      case 'equation':
        out.push(`<div style="font-family:Georgia,'Times New Roman',serif;font-style:italic;font-size:19px;text-align:center;margin:16px 0;padding:14px;background:#F7F6FB;border-radius:10px">${escapeHtml(renderEquation(b.expr))}</div>`);
        break;
      case 'toc': out.push(tocHtml(note)); break;
    }
  }
  return out.join('\n');
}

const PAPER_DIMS: Record<string, [number, number]> = {
  A4: [8.27, 11.69], Letter: [8.5, 11], Legal: [8.5, 14], A5: [5.83, 8.27],
};

export function buildHtml(note: Note): string {
  const p = note.page;
  let [wIn, hIn] = PAPER_DIMS[p.paper] || [p.customW, p.customH];
  if (p.paper === 'Custom') [wIn, hIn] = [p.customW, p.customH];
  if (p.orientation === 'landscape') [wIn, hIn] = [hIn, wIn];
  const stats = wordStats(note.blocks);
  const foot = note.footnotes.length
    ? `<div style="margin-top:32px;border-top:1px solid #DDD;padding-top:10px;font-size:12px;color:#555">${note.footnotes.map((fn, i) => `<div style="margin:2px 0"><sup>${i + 1}</sup> ${escapeHtml(fn.text)}</div>`).join('')}</div>`
    : '';
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${escapeHtml(note.title || 'Untitled')}</title>
<style>
@page { size: ${wIn}in ${hIn}in; margin: ${Math.max(10, p.margin * 0.75)}px; }
body { font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif; background:${p.pageColor}; color:#191325; margin:0; padding:8px; }
h1,h2,h3,h4,h5,h6,p { margin-top:0; }
</style></head><body>
${note.title ? `<div style="font-size:13px;color:#999;margin-bottom:2px">${escapeHtml(note.title)} \u00b7 ${stats.words} words</div>` : ''}
${blocksHtml(note)}
${foot}
</body></html>`;
}

export function buildText(note: Note): string {
  const lines: string[] = [note.title || 'Untitled', ''];
  let num = 0;
  for (const b of note.blocks) {
    if (b.type !== 'text' || b.list !== 'number') num = 0;
    switch (b.type) {
      case 'text': {
        if (b.list === 'number') num += 1;
        const prefix = b.list === 'bullet' ? '\u2022 ' : b.list === 'number' ? `${num}. ` : '';
        lines.push('  '.repeat(b.indent) + prefix + b.text);
        break;
      }
      case 'divider': lines.push('\n----------\n'); break;
      case 'image': lines.push(`[Image${b.caption ? ': ' + b.caption : ''}]`); break;
      case 'drawing': lines.push('[Drawing]'); break;
      case 'equation': lines.push(`[Equation] ${renderEquation(b.expr)}`); break;
      case 'table':
        b.rows.forEach(r => lines.push(r.join('  |  ')));
        break;
      case 'chart':
        lines.push(`[Chart: ${b.title || b.chartType}] ${b.data.map(d => `${d.label}: ${d.value}`).join(', ')}`);
        break;
      case 'toc':
        lines.push('Table of Contents:');
        tocEntries(note.blocks).forEach(e => lines.push(`${'  '.repeat(e.level)}- ${e.text}`));
        break;
    }
  }
  if (note.footnotes.length) {
    lines.push('', '--- Footnotes ---');
    note.footnotes.forEach((fn, i) => lines.push(`[${i + 1}] ${fn.text}`));
  }
  return lines.join('\n');
}

export function buildMarkdown(note: Note): string {
  const lines: string[] = [`# ${note.title || 'Untitled'}`, ''];
  let num = 0;
  for (const b of note.blocks) {
    if (b.type !== 'text' || b.list !== 'number') num = 0;
    switch (b.type) {
      case 'text': {
        if (b.list === 'number') num += 1;
        let t = b.text;
        if (b.bold) t = `**${t}**`;
        if (b.italic) t = `*${t}*`;
        if (b.strike) t = `~~${t}~~`;
        const head = b.style === 'title' ? '# ' : /^h[1-6]$/.test(b.style) ? '#'.repeat(parseInt(b.style[1], 10) + 1) + ' ' : '';
        const prefix = b.list === 'bullet' ? '- ' : b.list === 'number' ? `${num}. ` : '';
        lines.push(head + prefix + t);
        break;
      }
      case 'divider': lines.push('\n---\n'); break;
      case 'image': lines.push(`![${b.caption || 'image'}](${b.uri})`); break;
      case 'drawing': lines.push('*[Drawing]*'); break;
      case 'equation': lines.push(`$$ ${b.expr} $$`); break;
      case 'table': {
        const [head, ...rest] = b.rows;
        if (head) {
          lines.push('| ' + head.join(' | ') + ' |');
          lines.push('| ' + head.map(() => '---').join(' | ') + ' |');
          rest.forEach(r => lines.push('| ' + r.join(' | ') + ' |'));
        }
        break;
      }
      case 'chart':
        lines.push(`**${b.title || 'Chart'}** (${b.chartType})`);
        b.data.forEach(d => lines.push(`- ${d.label}: ${d.value}`));
        break;
      case 'toc':
        lines.push('## Table of Contents');
        tocEntries(note.blocks).forEach(e => lines.push(`${'  '.repeat(e.level)}- ${e.text}`));
        break;
    }
  }
  if (note.footnotes.length) {
    lines.push('', '---');
    note.footnotes.forEach((fn, i) => lines.push(`[^${i + 1}]: ${fn.text}`));
  }
  return lines.join('\n');
}

const safeName = (s: string) => (s || 'note').replace(/[^a-z0-9\-_ ]/gi, '').trim().replace(/\s+/g, '-').slice(0, 48) || 'note';

function webDownload(filename: string, content: string, mime: string) {
  const g = globalThis as any;
  const blob = new g.Blob([content], { type: mime });
  const url = g.URL.createObjectURL(blob);
  const a = g.document.createElement('a');
  a.href = url;
  a.download = filename;
  g.document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    g.document.body.removeChild(a);
    g.URL.revokeObjectURL(url);
  }, 500);
}

function webPrint(html: string) {
  const g = globalThis as any;
  const iframe = g.document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  g.document.body.appendChild(iframe);
  const doc = iframe.contentWindow.document;
  doc.open();
  doc.write(html);
  doc.close();
  setTimeout(() => {
    iframe.contentWindow.focus();
    iframe.contentWindow.print();
    setTimeout(() => g.document.body.removeChild(iframe), 2000);
  }, 350);
}

async function nativeWriteAndShare(filename: string, content: string, mime: string, uti?: string) {
  const uri = FileSystem.documentDirectory + filename;
  await FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 });
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(uri, { mimeType: mime, dialogTitle: filename, UTI: uti });
  } else {
    await Share.share({ message: content, title: filename });
  }
}

export type ExportFormat = 'pdf' | 'doc' | 'txt' | 'md';

export async function exportNote(note: Note, fmt: ExportFormat): Promise<string> {
  const name = safeName(note.title);
  if (fmt === 'pdf') {
    const html = buildHtml(note);
    if (Platform.OS === 'web') {
      webPrint(html);
      return 'Opened print dialog (choose Save as PDF)';
    }
    const { uri } = await Print.printToFileAsync({ html, base64: false });
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(uri, { mimeType: 'application/pdf', dialogTitle: `${name}.pdf`, UTI: 'com.adobe.pdf' });
    }
    return 'PDF exported';
  }
  if (fmt === 'doc') {
    const html = buildHtml(note);
    if (Platform.OS === 'web') {
      webDownload(`${name}.doc`, html, 'application/msword');
      return 'Word document downloaded';
    }
    await nativeWriteAndShare(`${name}.doc`, html, 'application/msword', 'com.microsoft.word.doc');
    return 'Word document exported';
  }
  if (fmt === 'md') {
    const md = buildMarkdown(note);
    if (Platform.OS === 'web') {
      webDownload(`${name}.md`, md, 'text/markdown');
      return 'Markdown downloaded';
    }
    await nativeWriteAndShare(`${name}.md`, md, 'text/markdown');
    return 'Markdown exported';
  }
  const txt = buildText(note);
  if (Platform.OS === 'web') {
    webDownload(`${name}.txt`, txt, 'text/plain');
    return 'Text file downloaded';
  }
  await nativeWriteAndShare(`${name}.txt`, txt, 'text/plain', 'public.plain-text');
  return 'Text file exported';
}

export async function printNote(note: Note): Promise<string> {
  const html = buildHtml(note);
  if (Platform.OS === 'web') {
    webPrint(html);
    return 'Opened print dialog';
  }
  await Print.printAsync({ html });
  return 'Sent to printer';
}

export async function shareNote(note: Note): Promise<void> {
  const text = buildText(note);
  await Share.share({
    title: note.title || 'Note',
    message: Platform.OS === 'ios' ? text : `${note.title || 'Note'}\n\n${text}`,
  });
}

import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

export const KEYS = {
  notes: 'notely.notes.v1',
  notebooks: 'notely.notebooks.v1',
  settings: 'notely.settings.v1',
  pin: 'notely.pin.hash',
};

export async function loadJSON<T>(key: string): Promise<T | null> {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export async function saveJSON(key: string, value: unknown): Promise<void> {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch {
    // storage full or unavailable - fail silently, keep in-memory state
  }
}

/** djb2 hash - adequate for a local app-lock PIN */
export function hashPin(pin: string): string {
  let h = 5381;
  const salted = 'notely::' + pin + '::lock';
  for (let i = 0; i < salted.length; i++) {
    h = ((h << 5) + h + salted.charCodeAt(i)) >>> 0;
  }
  return h.toString(16) + '.' + salted.length.toString(16);
}

export async function secureSet(key: string, value: string): Promise<void> {
  if (Platform.OS === 'web') {
    await AsyncStorage.setItem(key, value);
    return;
  }
  try {
    await SecureStore.setItemAsync(key, value);
  } catch {
    await AsyncStorage.setItem(key, value);
  }
}

export async function secureGet(key: string): Promise<string | null> {
  if (Platform.OS === 'web') return AsyncStorage.getItem(key);
  try {
    const v = await SecureStore.getItemAsync(key);
    if (v !== null) return v;
    return AsyncStorage.getItem(key);
  } catch {
    return AsyncStorage.getItem(key);
  }
}

export async function secureDelete(key: string): Promise<void> {
  if (Platform.OS === 'web') {
    await AsyncStorage.removeItem(key);
    return;
  }
  try {
    await SecureStore.deleteItemAsync(key);
  } catch {
    // ignore
  }
  await AsyncStorage.removeItem(key);
}

export async function haptic(kind: 'light' | 'medium' | 'success' = 'light') {
  if (Platform.OS === 'web') return;
  try {
    const Haptics = require('expo-haptics');
    if (kind === 'success') await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else await Haptics.impactAsync(kind === 'medium' ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Light);
  } catch {
    // haptics unavailable
  }
}

import React, { useEffect, useRef, useState } from 'react';
import { Animated, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../store/ThemeContext';
import { KEYS, hashPin, haptic, secureGet } from '../lib/storage';

export default function LockScreen({ onUnlock }: { onUnlock: () => void }) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { settings } = useApp();
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const shake = useRef(new Animated.Value(0)).current;

  const tryBiometric = async () => {
    if (Platform.OS === 'web' || !settings.biometric) return;
    try {
      const LA = require('expo-local-authentication');
      const has = await LA.hasHardwareAsync();
      const enrolled = await LA.isEnrolledAsync();
      if (!has || !enrolled) return;
      const res = await LA.authenticateAsync({ promptMessage: 'Unlock Notely', cancelLabel: 'Use PIN' });
      if (res.success) onUnlock();
    } catch {
      // biometrics unavailable - PIN remains
    }
  };

  useEffect(() => {
    const t = setTimeout(tryBiometric, 400);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const shakeAnim = () => {
    Animated.sequence([
      Animated.timing(shake, { toValue: 12, duration: 55, useNativeDriver: true }),
      Animated.timing(shake, { toValue: -12, duration: 55, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 8, duration: 55, useNativeDriver: true }),
      Animated.timing(shake, { toValue: -8, duration: 55, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 0, duration: 55, useNativeDriver: true }),
    ]).start();
  };

  const submit = async (value: string) => {
    const saved = await secureGet(KEYS.pin);
    if (saved && saved === hashPin(value)) {
      haptic('success');
      onUnlock();
    } else {
      haptic('medium');
      setError('Incorrect PIN');
      shakeAnim();
      setTimeout(() => { setPin(''); setError(''); }, 450);
    }
  };

  const press = (d: string) => {
    if (pin.length >= 4) return;
    haptic();
    const next = pin + d;
    setPin(next);
    setError('');
    if (next.length === 4) setTimeout(() => submit(next), 140);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: insets.top, paddingBottom: insets.bottom }}>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <View style={[styles.logo, { backgroundColor: colors.primary, shadowColor: colors.primary }]}>
          <Ionicons name="create" size={34} color="#fff" />
        </View>
        <Text style={{ fontSize: 24, fontWeight: '800', color: colors.text, letterSpacing: -0.4, marginTop: 18 }}>Notely</Text>
        <Text style={{ fontSize: 13.5, color: colors.faint, fontWeight: '600', marginTop: 4, marginBottom: 26 }}>
          Enter your PIN to continue
        </Text>

        <Animated.View style={{ flexDirection: 'row', gap: 18, marginBottom: 12, transform: [{ translateX: shake }] }}>
          {[0, 1, 2, 3].map(i => (
            <View key={i} style={{
              width: 17, height: 17, borderRadius: 9,
              backgroundColor: pin.length > i ? colors.primary : 'transparent',
              borderWidth: 2, borderColor: pin.length > i ? colors.primary : colors.border,
            }} />
          ))}
        </Animated.View>
        <Text style={{ color: colors.red, fontSize: 13, fontWeight: '600', height: 20, marginBottom: 16 }}>{error}</Text>

        <View style={{ width: 264 }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 16 }}>
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'bio', '0', 'del'].map((k, i) => {
              if (k === 'bio') {
                return settings.biometric && Platform.OS !== 'web' ? (
                  <Pressable key={i} onPress={tryBiometric} style={[styles.key, { backgroundColor: 'transparent' }]}>
                    <Ionicons name="finger-print" size={30} color={colors.primary} />
                  </Pressable>
                ) : <View key={i} style={styles.key} />;
              }
              if (k === 'del') {
                return (
                  <Pressable key={i} onPress={() => setPin(p => p.slice(0, -1))} style={[styles.key, { backgroundColor: 'transparent' }]}>
                    <Ionicons name="backspace-outline" size={26} color={colors.subtext} />
                  </Pressable>
                );
              }
              return (
                <Pressable key={i} onPress={() => press(k)} style={[styles.key, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <Text style={{ fontSize: 27, fontWeight: '700', color: colors.text }}>{k}</Text>
                </Pressable>
              );
            })}
          </View>
        </View>
      </View>
      <Text style={{ textAlign: 'center', fontSize: 11.5, color: colors.faint, fontWeight: '600', paddingBottom: 14 }}>
        Your notes never leave this device without you.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  logo: {
    width: 76, height: 76, borderRadius: 26,
    alignItems: 'center', justifyContent: 'center',
    shadowOpacity: 0.45, shadowRadius: 20, shadowOffset: { width: 0, height: 10 }, elevation: 10,
  },
  key: {
    width: 72, height: 72, borderRadius: 24, borderWidth: 1,
    borderColor: 'transparent', alignItems: 'center', justifyContent: 'center',
  },
});

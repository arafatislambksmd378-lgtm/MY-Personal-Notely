import React, { useState } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../store/ThemeContext';
import { Sheet, SheetHeader } from '../components/ui';
import { KEYS, hashPin, secureDelete, secureSet } from '../lib/storage';
import { soft } from '../theme';

function Row({
  icon, iconColor, title, subtitle, right, onPress,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  iconColor: string;
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
  onPress?: () => void;
}) {
  const { colors } = useTheme();
  return (
    <Pressable onPress={onPress} disabled={!onPress} style={[styles.row, { borderColor: colors.border }]}>
      <View style={[styles.rowIcon, { backgroundColor: soft(iconColor, 0.14) }]}>
        <Ionicons name={icon} size={18} color={iconColor} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 15.5, fontWeight: '600', color: colors.text }}>{title}</Text>
        {!!subtitle && <Text style={{ fontSize: 12.5, color: colors.faint, marginTop: 1 }}>{subtitle}</Text>}
      </View>
      {right}
    </Pressable>
  );
}

export default function SettingsScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { settings, updateSettings, notes, notebooks } = useApp();

  const [pinVisible, setPinVisible] = useState(false);
  const [pinStep, setPinStep] = useState<'new' | 'confirm'>('new');
  const [pin, setPin] = useState('');
  const [firstPin, setFirstPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [nameVisible, setNameVisible] = useState(false);
  const [nameDraft, setNameDraft] = useState(settings.userName);

  const startPinSetup = () => {
    setPin('');
    setFirstPin('');
    setPinStep('new');
    setPinError('');
    setPinVisible(true);
  };

  const onPinDigit = (d: string) => {
    if (pin.length >= 4) return;
    const next = pin + d;
    setPin(next);
    if (next.length === 4) {
      setTimeout(() => {
        if (pinStep === 'new') {
          setFirstPin(next);
          setPin('');
          setPinStep('confirm');
        } else {
          if (next === firstPin) {
            secureSet(KEYS.pin, hashPin(next));
            updateSettings({ lockEnabled: true });
            setPinVisible(false);
          } else {
            setPinError('PINs did not match - try again');
            setPin('');
            setFirstPin('');
            setPinStep('new');
          }
        }
      }, 120);
    }
  };

  const disableLock = async () => {
    await secureDelete(KEYS.pin);
    updateSettings({ lockEnabled: false, biometric: false });
  };

  const bioSupported = Platform.OS !== 'web';

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.bg }}
      contentContainerStyle={{ padding: 20, paddingTop: insets.top + 12, paddingBottom: 60 }}
      showsVerticalScrollIndicator={false}
    >
      <Text style={{ fontSize: 27, fontWeight: '800', color: colors.text, letterSpacing: -0.6, marginBottom: 18 }}>Settings</Text>

      <Pressable
        onPress={() => { setNameDraft(settings.userName); setNameVisible(true); }}
        style={[styles.profileCard, { backgroundColor: colors.primary, shadowColor: colors.primary }]}
      >
        <View style={styles.profileAvatar}>
          <Text style={{ fontSize: 22, fontWeight: '800', color: colors.primary }}>
            {(settings.userName || 'W').charAt(0).toUpperCase()}
          </Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: '#fff' }}>{settings.userName}</Text>
          <Text style={{ fontSize: 12.5, color: 'rgba(255,255,255,0.75)', fontWeight: '600' }}>Personal workspace · stored on this device</Text>
        </View>
        <Ionicons name="create-outline" size={18} color="rgba(255,255,255,0.85)" />
      </Pressable>

      <Text style={[styles.section, { color: colors.faint }]}>APPEARANCE</Text>
      <View style={[styles.group, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Row
          icon="moon" iconColor={colors.primary} title="Dark mode"
          subtitle="Easier on the eyes at night"
          right={<Switch value={settings.darkMode} onValueChange={v => updateSettings({ darkMode: v })} trackColor={{ true: colors.primary, false: colors.border }} thumbColor="#fff" />}
        />
        <Row
          icon="color-palette" iconColor={colors.pink} title="Accent system"
          subtitle="Purple · green · blue · yellow"
          right={
            <View style={{ flexDirection: 'row', gap: 4 }}>
              {[colors.primary, colors.green, colors.blue, colors.yellow].map((c, i) => (
                <View key={i} style={{ width: 14, height: 14, borderRadius: 7, backgroundColor: c }} />
              ))}
            </View>
          }
        />
      </View>

      <Text style={[styles.section, { color: colors.faint }]}>SECURITY</Text>
      <View style={[styles.group, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Row
          icon="lock-closed" iconColor={colors.blue} title="App lock"
          subtitle={settings.lockEnabled ? 'PIN protection is on' : 'Require a PIN to open Notely'}
          right={
            <Switch
              value={settings.lockEnabled}
              onValueChange={v => { v ? startPinSetup() : disableLock(); }}
              trackColor={{ true: colors.primary, false: colors.border }} thumbColor="#fff"
            />
          }
        />
        {settings.lockEnabled && (
          <>
            <Row icon="keypad" iconColor={colors.yellow} title="Change PIN" onPress={startPinSetup}
              right={<Ionicons name="chevron-forward" size={17} color={colors.faint} />} />
            {bioSupported && (
              <Row
                icon="finger-print" iconColor={colors.green} title="Biometric unlock"
                subtitle={settings.biometric ? 'Fingerprint / Face enabled' : 'Use device biometrics'}
                right={<Switch value={settings.biometric} onValueChange={v => updateSettings({ biometric: v })} trackColor={{ true: colors.primary, false: colors.border }} thumbColor="#fff" />}
              />
            )}
          </>
        )}
      </View>

      <Text style={[styles.section, { color: colors.faint }]}>EDITOR</Text>
      <View style={[styles.group, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Row
          icon="checkmark-circle" iconColor={colors.green} title="Spelling & grammar"
          subtitle="Auto-check while reviewing"
          right={<Switch value={settings.spellcheck} onValueChange={v => updateSettings({ spellcheck: v })} trackColor={{ true: colors.primary, false: colors.border }} thumbColor="#fff" />}
        />
        <Row
          icon="save" iconColor={colors.blue} title="Auto-save"
          subtitle="Always on · saves as you type"
          right={<Ionicons name="checkmark-circle" size={19} color={colors.green} />}
        />
        <Row
          icon="time" iconColor={colors.yellow} title="Version history"
          subtitle="Snapshots kept for every note"
          right={<Ionicons name="checkmark-circle" size={19} color={colors.green} />}
        />
      </View>

      <Text style={[styles.section, { color: colors.faint }]}>ABOUT</Text>
      <View style={[styles.group, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Row icon="document-text" iconColor={colors.primary} title="Notely" subtitle="Premium notes · v1.0.0"
          right={<Text style={{ fontSize: 12.5, color: colors.faint, fontWeight: '700' }}>{notes.length} notes</Text>} />
        <Row icon="albums" iconColor={colors.pink} title="Library"
          subtitle={`${notebooks.length} notebooks · local-first storage`} />
      </View>

      {/* PIN setup */}
      <Sheet visible={pinVisible} onClose={() => setPinVisible(false)}>
        <SheetHeader title={pinStep === 'new' ? 'Create a PIN' : 'Confirm your PIN'} onClose={() => setPinVisible(false)} />
        <Text style={{ fontSize: 13.5, color: colors.subtext, marginBottom: 18 }}>
          {pinStep === 'new' ? 'Choose a 4-digit PIN to lock Notely.' : 'Enter the same PIN once more.'}
        </Text>
        <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 16, marginBottom: 20 }}>
          {[0, 1, 2, 3].map(i => (
            <View key={i} style={{
              width: 16, height: 16, borderRadius: 8,
              backgroundColor: pin.length > i ? colors.primary : colors.border,
            }} />
          ))}
        </View>
        {!!pinError && <Text style={{ color: colors.red, textAlign: 'center', marginBottom: 10, fontWeight: '600' }}>{pinError}</Text>}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 12 }}>
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'].map((d, i) => (
            d === '' ? <View key={i} style={{ width: 68, height: 68 }} /> : (
              <Pressable
                key={i}
                onPress={() => d === '⌫' ? setPin(p => p.slice(0, -1)) : onPinDigit(d)}
                style={[styles.key, { backgroundColor: colors.surface, borderColor: colors.border }]}
              >
                {d === '⌫'
                  ? <Ionicons name="backspace-outline" size={22} color={colors.text} />
                  : <Text style={{ fontSize: 24, fontWeight: '700', color: colors.text }}>{d}</Text>}
              </Pressable>
            )
          ))}
        </View>
      </Sheet>

      {/* rename */}
      <Sheet visible={nameVisible} onClose={() => setNameVisible(false)}>
        <SheetHeader title="Your name" onClose={() => setNameVisible(false)} />
        <TextInput
          value={nameDraft}
          onChangeText={setNameDraft}
          autoFocus
          placeholder="Writer"
          placeholderTextColor={colors.faint}
          style={[styles.nameInput, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
        />
        <Pressable
          onPress={() => { updateSettings({ userName: nameDraft.trim() || 'Writer' }); setNameVisible(false); }}
          style={[styles.saveBtn, { backgroundColor: colors.primary }]}
        >
          <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>Save</Text>
        </Pressable>
      </Sheet>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  profileCard: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    padding: 18, borderRadius: 24, marginBottom: 8,
    shadowOpacity: 0.35, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 8,
  },
  profileAvatar: {
    width: 52, height: 52, borderRadius: 18, backgroundColor: '#fff',
    alignItems: 'center', justifyContent: 'center',
  },
  section: { fontSize: 11.5, fontWeight: '800', letterSpacing: 1.2, marginTop: 20, marginBottom: 8, marginLeft: 4 },
  group: { borderRadius: 22, borderWidth: 1, overflow: 'hidden', paddingHorizontal: 14 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 13, paddingVertical: 13, borderBottomWidth: 0 },
  rowIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  key: {
    width: 68, height: 68, borderRadius: 22, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  nameInput: {
    borderRadius: 14, paddingHorizontal: 16, paddingVertical: 13,
    fontSize: 16, borderWidth: 1, marginBottom: 14, outlineStyle: 'none',
  } as object,
  saveBtn: { alignItems: 'center', paddingVertical: 14, borderRadius: 16 },
});

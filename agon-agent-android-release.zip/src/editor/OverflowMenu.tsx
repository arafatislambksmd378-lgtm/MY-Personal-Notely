import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';
import { Sheet, SheetHeader } from '../components/ui';
import { ACCENTS, soft } from '../theme';

export type MenuAction =
  | 'page' | 'find' | 'words' | 'spell' | 'versions'
  | 'comments' | 'bookmarks' | 'export' | 'print' | 'copy'
  | 'pin' | 'delete' | 'notebook';

export default function OverflowMenu({
  visible, onClose, onAction, pinned, noteColor, onColor, commentCount, versionCount,
}: {
  visible: boolean;
  onClose: () => void;
  onAction: (a: MenuAction) => void;
  pinned: boolean;
  noteColor: string;
  onColor: (c: string) => void;
  commentCount: number;
  versionCount: number;
}) {
  const { colors } = useTheme();

  const Item = ({ a, icon, color, label, badge }: {
    a: MenuAction; icon: keyof typeof Ionicons.glyphMap; color: string; label: string; badge?: number;
  }) => (
    <Pressable onPress={() => { onAction(a); }} style={styles.row}>
      <View style={[styles.icon, { backgroundColor: soft(color, 0.13) }]}>
        <Ionicons name={icon} size={17} color={color} />
      </View>
      <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: colors.text }}>{label}</Text>
      {!!badge && (
        <View style={[styles.badge, { backgroundColor: colors.primarySoft }]}>
          <Text style={{ fontSize: 11, fontWeight: '800', color: colors.primary }}>{badge}</Text>
        </View>
      )}
      <Ionicons name="chevron-forward" size={15} color={colors.faint} />
    </Pressable>
  );

  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.9}>
      <SheetHeader title="Note options" onClose={onClose} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={{ fontSize: 11.5, fontWeight: '800', color: colors.faint, letterSpacing: 1, marginBottom: 9 }}>CARD COLOR</Text>
        <View style={{ flexDirection: 'row', gap: 9, marginBottom: 14, flexWrap: 'wrap' }}>
          {ACCENTS.map(c => (
            <Pressable key={c} onPress={() => onColor(c)}
              style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: c, alignItems: 'center', justifyContent: 'center' }}>
              {noteColor === c && <Ionicons name="checkmark" size={15} color="#fff" />}
            </Pressable>
          ))}
        </View>
        <View style={{ borderTopWidth: 1, borderTopColor: colors.border }}>
          <Item a="page" icon="document" color={colors.blue} label="Page setup" />
          <Item a="find" icon="search" color={colors.primary} label="Find and replace" />
          <Item a="words" icon="speedometer" color={colors.green} label="Word count" />
          <Item a="spell" icon="checkmark-circle" color={colors.yellow} label="Spelling and grammar" />
          <Item a="versions" icon="time" color={colors.pink} label="Version history" badge={versionCount} />
          <Item a="comments" icon="chatbubbles" color={colors.blue} label="Comments" badge={commentCount} />
          <Item a="bookmarks" icon="bookmarks" color={colors.primary} label="Bookmarks" />
          <Item a="notebook" icon="albums" color={colors.green} label="Move to notebook" />
          <Item a="export" icon="share-social" color={colors.primary} label="Share & export" />
          <Item a="copy" icon="copy" color={colors.yellow} label="Make a copy" />
          <Item a="pin" icon="pin" color={colors.pink} label={pinned ? 'Unpin from top' : 'Pin to top'} />
        </View>
        <Pressable onPress={() => onAction('delete')} style={styles.row}>
          <View style={[styles.icon, { backgroundColor: colors.redSoft }]}>
            <Ionicons name="trash" size={17} color={colors.red} />
          </View>
          <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: colors.red }}>Delete note</Text>
        </Pressable>
        <View style={{ height: 8 }} />
      </ScrollView>
    </Sheet>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 11 },
  icon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 9, marginRight: 4 },
});

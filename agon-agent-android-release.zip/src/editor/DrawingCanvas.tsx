import React, { useMemo, useRef, useState } from 'react';
import { Modal, PanResponder, Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Path } from 'react-native-svg';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';
import { DrawPath, DrawPoint, DrawTool, DrawingBlock } from '../types';
import { calligraphyPath, pathHit, smoothLine, stabilizePoint } from '../lib/draw';
import { DRAW_COLORS } from '../theme';
import { TinySlider } from '../components/ui';
import { haptic } from '../lib/storage';

type ToolKey = DrawTool | 'eraser';

const TOOLS: { key: ToolKey; icon: keyof typeof Ionicons.glyphMap; label: string }[] = [
  { key: 'pen', icon: 'create', label: 'Pen' },
  { key: 'calligraphy', icon: 'brush', label: 'Calligraphy' },
  { key: 'highlighter', icon: 'flashlight', label: 'Highlighter' },
  { key: 'eraser', icon: 'bandage', label: 'Eraser' },
];

export default function DrawingCanvas({
  visible, onClose, onSave, existing, pageColor = '#FFFFFF',
}: {
  visible: boolean;
  onClose: () => void;
  onSave: (block: Omit<DrawingBlock, 'id'>) => void;
  existing?: DrawingBlock | null;
  pageColor?: string;
}) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const [paths, setPaths] = useState<DrawPath[]>([]);
  const [current, setCurrent] = useState<DrawPath | null>(null);
  const [tool, setTool] = useState<ToolKey>('pen');
  const [color, setColor] = useState(DRAW_COLORS[1]);
  const [width, setWidth] = useState(5);
  const [stabilize, setStabilize] = useState(true);
  const size = useRef({ w: 1, h: 1 });
  const wasVisible = useRef(false);

  if (visible && !wasVisible.current) {
    wasVisible.current = true;
    setPaths(existing ? JSON.parse(JSON.stringify(existing.paths)) : []);
    setCurrent(null);
  }
  if (!visible && wasVisible.current) wasVisible.current = false;

  const toNorm = (x: number, y: number): DrawPoint => ({
    x: Math.max(0, Math.min(1, x / size.current.w)),
    y: Math.max(0, Math.min(1, y / size.current.h)),
  });

  const pan = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderGrant: e => {
      const { locationX, locationY } = e.nativeEvent;
      const p = toNorm(locationX, locationY);
      if (tool === 'eraser') {
        setPaths(prev => prev.filter(pa => !pathHit({ ...pa, points: pa.points.map(q => ({ x: q.x * size.current.w, y: q.y * size.current.h })), width: pa.width * size.current.w }, { x: locationX, y: locationY }, 14)));
        return;
      }
      setCurrent({ points: [p], color, width: width / size.current.w, tool });
    },
    onPanResponderMove: e => {
      const { locationX, locationY } = e.nativeEvent;
      if (tool === 'eraser') {
        setPaths(prev => prev.filter(pa => !pathHit({ ...pa, points: pa.points.map(q => ({ x: q.x * size.current.w, y: q.y * size.current.h })), width: pa.width * size.current.w }, { x: locationX, y: locationY }, 14)));
        return;
      }
      const raw = toNorm(locationX, locationY);
      setCurrent(prev => {
        if (!prev) return prev;
        const pts = prev.points;
        const last = pts[pts.length - 1];
        const p = stabilize && pts.length > 0 ? stabilizePoint(last, raw, 0.55) : raw;
        const dx = (p.x - last.x) * size.current.w;
        const dy = (p.y - last.y) * size.current.h;
        if (Math.hypot(dx, dy) < 0.8) return prev;
        return { ...prev, points: [...pts, p] };
      });
    },
    onPanResponderRelease: () => {
      setCurrent(prev => {
        if (prev && prev.points.length > 0) setPaths(p2 => [...p2, prev]);
        return null;
      });
    },
    onPanResponderTerminate: () => setCurrent(null),
  }), [tool, color, width, stabilize]);

  const renderPath = (p: DrawPath, key: number | string) => {
    const w = size.current.w, h = size.current.h;
    const pts = p.points.map(q => ({ x: q.x * w, y: q.y * h }));
    const sw = Math.max(0.6, p.width * w);
    if (p.tool === 'calligraphy') {
      return <Path key={key} d={calligraphyPath(pts, sw)} fill={p.color} />;
    }
    return (
      <Path key={key} d={smoothLine(pts)} fill="none" stroke={p.color} strokeWidth={sw}
        strokeLinecap="round" strokeLinejoin="round" strokeOpacity={p.tool === 'highlighter' ? 0.35 : 1} />
    );
  };

  const save = () => {
    haptic('success');
    onSave({
      type: 'drawing',
      paths,
      aspect: size.current.h / size.current.w > 1 ? 0.72 : size.current.h / size.current.w,
    });
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <View style={{ flex: 1, backgroundColor: pageColor, paddingTop: insets.top, paddingBottom: insets.bottom }}>
        {/* header */}
        <View style={styles.header}>
          <Pressable onPress={onClose} style={[styles.headBtn, { backgroundColor: colors.surface }]}>
            <Ionicons name="close" size={20} color={colors.text} />
          </Pressable>
          <Text style={{ fontSize: 16, fontWeight: '800', color: '#191325' }}>Drawing</Text>
          <Pressable onPress={save} style={[styles.headBtn, { backgroundColor: '#7C4DFF', width: 'auto', paddingHorizontal: 16 }]}>
            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 14 }}>Insert</Text>
          </Pressable>
        </View>

        {/* canvas */}
        <View
          style={{ flex: 1 }}
          onLayout={e => { size.current = { w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height }; }}
          {...pan.panHandlers}
        >
          <Svg style={StyleSheet.absoluteFill}>
            {paths.map((p, i) => renderPath(p, i))}
            {current && renderPath(current, 'cur')}
          </Svg>
        </View>

        {/* floating tool palette */}
        <View style={[styles.toolPill, { top: insets.top + 72, shadowColor: colors.shadow }]}>
          {TOOLS.map(t => (
            <Pressable
              key={t.key}
              onPress={() => { haptic(); setTool(t.key); }}
              style={[styles.toolBtn, tool === t.key && { backgroundColor: '#7C4DFF' }]}
            >
              <Ionicons name={t.icon} size={19} color={tool === t.key ? '#fff' : '#6B6579'} />
            </Pressable>
          ))}
          <View style={{ width: 1, height: 22, backgroundColor: '#EEEAF7', marginVertical: 4 }} />
          <Pressable
            onPress={() => { haptic(); setPaths(p => p.slice(0, -1)); }}
            disabled={!paths.length}
            style={[styles.toolBtn, { opacity: paths.length ? 1 : 0.3 }]}
          >
            <Ionicons name="arrow-undo" size={19} color="#6B6579" />
          </Pressable>
          <Pressable
            onPress={() => { haptic('medium'); setPaths([]); }}
            disabled={!paths.length}
            style={[styles.toolBtn, { opacity: paths.length ? 1 : 0.3 }]}
          >
            <Ionicons name="trash-outline" size={19} color="#E5484D" />
          </Pressable>
        </View>

        {/* bottom controls */}
        <View style={[styles.bottomBar, { backgroundColor: 'rgba(255,255,255,0.96)', borderColor: '#EEEAF7', shadowColor: colors.shadow }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 4 }}>
            {DRAW_COLORS.map(c => (
              <Pressable key={c} onPress={() => { setColor(c); if (tool === 'eraser') setTool('pen'); }}>
                <View style={{
                  width: 28, height: 28, borderRadius: 14, backgroundColor: c,
                  borderWidth: color === c && tool !== 'eraser' ? 3 : 1,
                  borderColor: color === c && tool !== 'eraser' ? '#191325' : 'rgba(0,0,0,0.08)',
                }} />
              </Pressable>
            ))}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 6 }}>
            <Ionicons name="remove" size={15} color="#6B6579" />
            <View style={{ flex: 1 }}>
              <TinySlider value={width} min={1} max={18} onChange={setWidth} accent="#7C4DFF" />
            </View>
            <Ionicons name="add" size={15} color="#6B6579" />
            <View style={{ width: Math.max(4, width), height: Math.max(4, width), borderRadius: 9, backgroundColor: color, marginLeft: 4 }} />
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 }}>
            <Text style={{ fontSize: 12.5, fontWeight: '600', color: '#6B6579' }}>Stroke stabilization</Text>
            <Switch value={stabilize} onValueChange={setStabilize} trackColor={{ true: '#7C4DFF', false: '#DDD6FE' }} thumbColor="#fff" />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 10,
  },
  headBtn: {
    minWidth: 40, height: 40, borderRadius: 14,
    alignItems: 'center', justifyContent: 'center',
  },
  toolPill: {
    position: 'absolute', left: 12,
    backgroundColor: 'rgba(255,255,255,0.96)', borderRadius: 22,
    paddingVertical: 8, paddingHorizontal: 5, alignItems: 'center',
    borderWidth: 1, borderColor: '#EEEAF7',
    shadowOpacity: 1, shadowRadius: 14, shadowOffset: { width: 0, height: 6 }, elevation: 8,
  },
  toolBtn: {
    width: 38, height: 38, borderRadius: 19,
    alignItems: 'center', justifyContent: 'center', marginVertical: 2,
  },
  bottomBar: {
    marginHorizontal: 14, marginBottom: 8, borderRadius: 22,
    paddingHorizontal: 16, paddingVertical: 12,
    borderWidth: 1,
    shadowOpacity: 1, shadowRadius: 14, shadowOffset: { width: 0, height: 6 }, elevation: 8,
  },
});

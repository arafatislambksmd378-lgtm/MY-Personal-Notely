import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';
import { Sheet, SheetHeader, TinySlider } from '../components/ui';
import { Orientation, PageSetup, PaperSize } from '../types';
import { PAGE_COLOR_PRESETS } from '../theme';

const PAPERS: { key: PaperSize; dims: string }[] = [
  { key: 'A4', dims: '8.3 × 11.7 in' },
  { key: 'Letter', dims: '8.5 × 11 in' },
  { key: 'Legal', dims: '8.5 × 14 in' },
  { key: 'A5', dims: '5.8 × 8.3 in' },
  { key: 'Custom', dims: 'your size' },
];

const MARGINS = [
  { label: 'None', value: 0 },
  { label: 'Narrow', value: 22 },
  { label: 'Normal', value: 44 },
  { label: 'Wide', value: 72 },
];

export default function PageSetupSheet({
  visible, onClose, page, onChange,
}: {
  visible: boolean;
  onClose: () => void;
  page: PageSetup;
  onChange: (p: PageSetup) => void;
}) {
  const { colors } = useTheme();
  const [hex, setHex] = useState(page.pageColor);

  const set = (patch: Partial<PageSetup>) => onChange({ ...page, ...patch });

  const applyHex = (v: string) => {
    setHex(v);
    const m = /^#?([0-9a-fA-F]{6})$/.exec(v.trim());
    if (m) set({ pageColor: '#' + m[1] });
  };

  const orientCard = (o: Orientation, label: string, icon: keyof typeof Ionicons.glyphMap) => (
    <Pressable
      onPress={() => set({ orientation: o })}
      style={[styles.orient, {
        borderColor: page.orientation === o ? colors.primary : colors.border,
        backgroundColor: page.orientation === o ? colors.primarySoft : colors.card,
      }]}
    >
      <View style={{
        width: o === 'portrait' ? 34 : 50, height: o === 'portrait' ? 50 : 34,
        borderRadius: 6, backgroundColor: '#fff',
        borderWidth: 2, borderColor: page.orientation === o ? colors.primary : colors.faint,
        marginBottom: 8,
      }} />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
        <Ionicons name={icon} size={13} color={page.orientation === o ? colors.primary : colors.subtext} />
        <Text style={{ fontSize: 13, fontWeight: '700', color: page.orientation === o ? colors.primary : colors.subtext }}>{label}</Text>
      </View>
    </Pressable>
  );

  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.94}>
      <SheetHeader title="Page setup" onClose={onClose} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={styles.label}>ORIENTATION</Text>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          {orientCard('portrait', 'Portrait', 'phone-portrait-outline')}
          {orientCard('landscape', 'Landscape', 'phone-landscape-outline')}
        </View>

        <Text style={styles.label}>PAPER SIZE</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {PAPERS.map(p => (
            <Pressable
              key={p.key}
              onPress={() => set({ paper: p.key })}
              style={[styles.paperChip, {
                borderColor: page.paper === p.key ? colors.primary : colors.border,
                backgroundColor: page.paper === p.key ? colors.primarySoft : colors.card,
              }]}
            >
              <Text style={{ fontSize: 14, fontWeight: '800', color: page.paper === p.key ? colors.primary : colors.text }}>{p.key}</Text>
              <Text style={{ fontSize: 10.5, color: colors.faint, fontWeight: '600', marginTop: 2 }}>{p.dims}</Text>
            </Pressable>
          ))}
        </View>
        {page.paper === 'Custom' && (
          <View style={[styles.customBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={{ fontSize: 12.5, fontWeight: '600', color: colors.subtext }}>
              Width: {page.customW.toFixed(1)} in
            </Text>
            <TinySlider value={page.customW} min={4} max={14} onChange={v => set({ customW: Math.round(v * 10) / 10 })} accent={colors.primary} />
            <Text style={{ fontSize: 12.5, fontWeight: '600', color: colors.subtext, marginTop: 6 }}>
              Height: {page.customH.toFixed(1)} in
            </Text>
            <TinySlider value={page.customH} min={4} max={20} onChange={v => set({ customH: Math.round(v * 10) / 10 })} accent={colors.primary} />
          </View>
        )}

        <Text style={styles.label}>MARGINS</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 8 }}>
          {MARGINS.map(m => (
            <Pressable
              key={m.label}
              onPress={() => set({ margin: m.value })}
              style={[styles.marginChip, {
                borderColor: page.margin === m.value ? colors.primary : colors.border,
                backgroundColor: page.margin === m.value ? colors.primarySoft : colors.card,
              }]}
            >
              <Text style={{ fontSize: 12.5, fontWeight: '700', color: page.margin === m.value ? colors.primary : colors.subtext }}>{m.label}</Text>
            </Pressable>
          ))}
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ flex: 1 }}>
            <TinySlider value={page.margin} min={0} max={96} onChange={v => set({ margin: Math.round(v) })} accent={colors.blue} />
          </View>
          <Text style={{ fontSize: 13, fontWeight: '800', color: colors.blue, width: 44, textAlign: 'right' }}>{page.margin}px</Text>
        </View>

        <Text style={styles.label}>PAGE COLOR</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 12 }}>
          {PAGE_COLOR_PRESETS.map(c => (
            <Pressable key={c} onPress={() => { set({ pageColor: c }); setHex(c); }}
              style={[styles.colorDot, { backgroundColor: c, borderColor: page.pageColor === c ? colors.primary : colors.border, borderWidth: page.pageColor === c ? 2.5 : 1 }]}>
              {page.pageColor === c && <Ionicons name="checkmark" size={15} color={colors.primary} />}
            </Pressable>
          ))}
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 20 }}>
          <View style={[styles.colorDot, { backgroundColor: /^#[0-9a-fA-F]{6}$/.test(hex.trim()) ? (hex.startsWith('#') ? hex : '#' + hex) : '#fff', borderColor: colors.border, borderWidth: 1 }]} />
          <TextInput
            value={hex}
            onChangeText={applyHex}
            placeholder="#FFFFFF"
            placeholderTextColor={colors.faint}
            autoCapitalize="characters"
            style={[styles.hexInput, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
          />
          <Text style={{ fontSize: 12, color: colors.faint, flex: 1 }}>Any hex color</Text>
        </View>
      </ScrollView>
    </Sheet>
  );
}

const styles = StyleSheet.create({
  label: { fontSize: 11.5, fontWeight: '800', color: '#A29EB0', letterSpacing: 1, marginBottom: 10, marginTop: 18 },
  orient: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    paddingVertical: 16, borderRadius: 18, borderWidth: 2,
  },
  paperChip: {
    paddingHorizontal: 16, paddingVertical: 10, borderRadius: 15, borderWidth: 1.5,
    alignItems: 'center',
  },
  customBox: { marginTop: 10, borderRadius: 16, borderWidth: 1, padding: 14 },
  marginChip: {
    flex: 1, alignItems: 'center', paddingVertical: 10,
    borderRadius: 13, borderWidth: 1.5,
  },
  colorDot: {
    width: 36, height: 36, borderRadius: 18,
    alignItems: 'center', justifyContent: 'center',
  },
  hexInput: {
    width: 110, borderRadius: 12, borderWidth: 1,
    paddingHorizontal: 12, paddingVertical: 9, fontSize: 14, fontWeight: '700',
    outlineStyle: 'none',
  } as object,
});

import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';
import { Sheet, SheetHeader } from '../components/ui';
import { Note, TextBlock, VersionEntry } from '../types';
import { formatDateTime, wordStats } from '../lib/utils';
import { applyIssueFix, SpellIssue } from '../lib/spell';
import { soft } from '../theme';
import { haptic } from '../lib/storage';

/* ------------------------------ find & replace ----------------------------- */

export function FindReplaceSheet({
  visible, onClose, note, onApply,
}: {
  visible: boolean;
  onClose: () => void;
  note: Note;
  onApply: (find: string, replace: string, matchCase: boolean) => number;
}) {
  const { colors } = useTheme();
  const [find, setFind] = useState('');
  const [replace, setReplace] = useState('');
  const [matchCase, setMatchCase] = useState(false);
  const [doneMsg, setDoneMsg] = useState('');

  const matches = useMemo(() => {
    if (!find) return 0;
    let count = 0;
    for (const b of note.blocks) {
      if (b.type !== 'text') continue;
      const hay = matchCase ? b.text : b.text.toLowerCase();
      const needle = matchCase ? find : find.toLowerCase();
      let idx = hay.indexOf(needle);
      while (idx !== -1) { count++; idx = hay.indexOf(needle, idx + needle.length); }
    }
    return count;
  }, [find, note.blocks, matchCase]);

  return (
    <Sheet visible={visible} onClose={onClose}>
      <SheetHeader title="Find and replace" onClose={onClose} />
      <View style={[styles.field, { backgroundColor: colors.inputBg, borderColor: colors.border }]}>
        <Ionicons name="search" size={16} color={colors.faint} />
        <TextInput
          value={find}
          onChangeText={v => { setFind(v); setDoneMsg(''); }}
          placeholder="Find in document"
          placeholderTextColor={colors.faint}
          autoFocus
          style={[styles.input, { color: colors.text }]}
        />
        {!!find && (
          <View style={[styles.countBadge, { backgroundColor: matches ? colors.primarySoft : colors.redSoft }]}>
            <Text style={{ fontSize: 11.5, fontWeight: '800', color: matches ? colors.primary : colors.red }}>
              {matches} {matches === 1 ? 'match' : 'matches'}
            </Text>
          </View>
        )}
      </View>
      <View style={[styles.field, { backgroundColor: colors.inputBg, borderColor: colors.border }]}>
        <Ionicons name="swap-horizontal" size={16} color={colors.faint} />
        <TextInput
          value={replace}
          onChangeText={setReplace}
          placeholder="Replace with"
          placeholderTextColor={colors.faint}
          style={[styles.input, { color: colors.text }]}
        />
      </View>
      <Pressable onPress={() => setMatchCase(v => !v)} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginVertical: 10 }}>
        <Ionicons name={matchCase ? 'checkbox' : 'square-outline'} size={19} color={matchCase ? colors.primary : colors.faint} />
        <Text style={{ fontSize: 13.5, color: colors.subtext, fontWeight: '600' }}>Match case</Text>
      </Pressable>
      {!!doneMsg && <Text style={{ color: colors.green, fontWeight: '700', fontSize: 13, marginBottom: 10 }}>{doneMsg}</Text>}
      <Pressable
        onPress={() => {
          if (!find || !matches) return;
          const n = onApply(find, replace, matchCase);
          haptic('success');
          setDoneMsg(`Replaced ${n} ${n === 1 ? 'occurrence' : 'occurrences'}`);
        }}
        disabled={!find || !matches}
        style={[styles.primaryBtn, { backgroundColor: colors.primary, opacity: !find || !matches ? 0.4 : 1 }]}
      >
        <Ionicons name="swap-horizontal" size={16} color="#fff" />
        <Text style={{ color: '#fff', fontWeight: '700', fontSize: 14.5 }}>Replace all</Text>
      </Pressable>
    </Sheet>
  );
}

/* -------------------------------- word count ------------------------------- */

export function WordCountSheet({ visible, onClose, note }: { visible: boolean; onClose: () => void; note: Note }) {
  const { colors } = useTheme();
  const s = wordStats(note.blocks);
  const items = [
    { label: 'Words', value: s.words, icon: 'text' as const, color: colors.primary },
    { label: 'Characters', value: s.chars, icon: 'code' as const, color: colors.blue },
    { label: 'No spaces', value: s.charsNoSpaces, icon: 'remove' as const, color: colors.yellow },
    { label: 'Pages', value: s.pages, icon: 'document' as const, color: colors.green },
    { label: 'Reading time', value: `~${s.readingMin} min`, icon: 'time' as const, color: colors.pink },
    { label: 'Blocks', value: note.blocks.length, icon: 'grid' as const, color: colors.subtext },
  ];
  return (
    <Sheet visible={visible} onClose={onClose}>
      <SheetHeader title="Word count" onClose={onClose} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {items.map((it, i) => (
          <View key={i} style={[styles.statCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.statIcon, { backgroundColor: soft(it.color, 0.14) }]}>
              <Ionicons name={it.icon} size={16} color={it.color} />
            </View>
            <Text style={{ fontSize: 20, fontWeight: '800', color: colors.text }}>{it.value}</Text>
            <Text style={{ fontSize: 11.5, fontWeight: '600', color: colors.faint }}>{it.label}</Text>
          </View>
        ))}
      </View>
    </Sheet>
  );
}

/* ------------------------------ version history ---------------------------- */

export function VersionsSheet({
  visible, onClose, note, onRestore,
}: {
  visible: boolean;
  onClose: () => void;
  note: Note;
  onRestore: (v: VersionEntry) => void;
}) {
  const { colors } = useTheme();
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const versions = [...note.versions].reverse();

  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.8}>
      <SheetHeader title="Version history" onClose={onClose} />
      {versions.length === 0 ? (
        <View style={{ alignItems: 'center', paddingVertical: 26 }}>
          <Ionicons name="time-outline" size={36} color={colors.faint} />
          <Text style={{ color: colors.subtext, fontSize: 13.5, marginTop: 10, textAlign: 'center', lineHeight: 20 }}>
            No snapshots yet.{'\n'}Versions are captured automatically as you edit.
          </Text>
        </View>
      ) : (
        <FlatList
          data={versions}
          keyExtractor={v => v.id}
          style={{ maxHeight: 420 }}
          renderItem={({ item: v, index }) => (
            <View style={[styles.versionRow, { borderColor: colors.border, backgroundColor: colors.surface }]}>
              <View style={[styles.versionDot, { backgroundColor: index === 0 ? colors.primary : colors.faint }]} />
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: '700', color: colors.text }}>
                  {formatDateTime(v.at)}{index === 0 ? '  ·  Latest' : ''}
                </Text>
                <Text numberOfLines={1} style={{ fontSize: 12, color: colors.faint, marginTop: 2 }}>
                  {v.title || 'Untitled'} · {v.words} words · {v.blocks.length} blocks
                </Text>
              </View>
              {confirmId === v.id ? (
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  <Pressable onPress={() => { onRestore(v); setConfirmId(null); onClose(); }}
                    style={[styles.smallBtn, { backgroundColor: colors.primary }]}>
                    <Text style={{ color: '#fff', fontSize: 12, fontWeight: '700' }}>Restore</Text>
                  </Pressable>
                  <Pressable onPress={() => setConfirmId(null)} style={[styles.smallBtn, { backgroundColor: colors.border }]}>
                    <Text style={{ color: colors.text, fontSize: 12, fontWeight: '700' }}>Cancel</Text>
                  </Pressable>
                </View>
              ) : (
                <Pressable onPress={() => setConfirmId(v.id)} style={[styles.smallBtn, { backgroundColor: colors.primarySoft }]}>
                  <Ionicons name="refresh" size={13} color={colors.primary} />
                  <Text style={{ color: colors.primary, fontSize: 12, fontWeight: '700' }}>Restore</Text>
                </Pressable>
              )}
            </View>
          )}
        />
      )}
    </Sheet>
  );
}

/* --------------------------------- comments -------------------------------- */

export function CommentsSheet({
  visible, onClose, note, focusedBlockId, onAdd, onDelete,
}: {
  visible: boolean;
  onClose: () => void;
  note: Note;
  focusedBlockId: string | null;
  onAdd: (text: string) => void;
  onDelete: (id: string) => void;
}) {
  const { colors } = useTheme();
  const [draft, setDraft] = useState('');

  const anchorText = (blockId: string) => {
    const b = note.blocks.find(x => x.id === blockId);
    if (!b) return 'page';
    if (b.type === 'text') return (b as TextBlock).text.slice(0, 40) || 'empty paragraph';
    return b.type;
  };

  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.85}>
      <SheetHeader title={`Comments (${note.comments.length})`} onClose={onClose} />
      <View style={[styles.field, { backgroundColor: colors.inputBg, borderColor: colors.border }]}>
        <Ionicons name="chatbubble-ellipses" size={16} color={colors.faint} />
        <TextInput
          value={draft}
          onChangeText={setDraft}
          placeholder={focusedBlockId ? `Comment on "${anchorText(focusedBlockId)}"` : 'Comment on this page'}
          placeholderTextColor={colors.faint}
          style={[styles.input, { color: colors.text }]}
          onSubmitEditing={() => { if (draft.trim()) { onAdd(draft.trim()); setDraft(''); } }}
          returnKeyType="send"
        />
        <Pressable
          onPress={() => { if (draft.trim()) { onAdd(draft.trim()); setDraft(''); haptic(); } }}
          disabled={!draft.trim()}
          style={[styles.sendBtn, { backgroundColor: colors.primary, opacity: draft.trim() ? 1 : 0.4 }]}
        >
          <Ionicons name="send" size={13} color="#fff" />
        </Pressable>
      </View>
      <ScrollView style={{ maxHeight: 320 }} showsVerticalScrollIndicator={false}>
        {note.comments.length === 0 && (
          <Text style={{ color: colors.faint, fontSize: 13, textAlign: 'center', paddingVertical: 20 }}>
            No comments yet. Add a note for yourself or a collaborator.
          </Text>
        )}
        {[...note.comments].reverse().map(c => (
          <View key={c.id} style={[styles.commentCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.commentDot, { backgroundColor: colors.yellow }]}>
              <Ionicons name="chatbubble" size={11} color="#fff" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 13.5, color: colors.text, lineHeight: 19 }}>{c.text}</Text>
              <Text style={{ fontSize: 11, color: colors.faint, marginTop: 4 }}>
                on “{anchorText(c.blockId)}…” · {formatDateTime(c.at)}
              </Text>
            </View>
            <Pressable onPress={() => onDelete(c.id)} hitSlop={8}>
              <Ionicons name="close" size={16} color={colors.faint} />
            </Pressable>
          </View>
        ))}
      </ScrollView>
    </Sheet>
  );
}

/* --------------------------------- bookmarks ------------------------------- */

export function BookmarksSheet({
  visible, onClose, note, onJump, onDelete,
}: {
  visible: boolean;
  onClose: () => void;
  note: Note;
  onJump: (blockId: string) => void;
  onDelete: (id: string) => void;
}) {
  const { colors } = useTheme();
  return (
    <Sheet visible={visible} onClose={onClose}>
      <SheetHeader title={`Bookmarks (${note.bookmarks.length})`} onClose={onClose} />
      {note.bookmarks.length === 0 ? (
        <Text style={{ color: colors.faint, fontSize: 13, textAlign: 'center', paddingVertical: 20, lineHeight: 20 }}>
          No bookmarks yet.{'\n'}Place the cursor in a paragraph and use Insert → Bookmark.
        </Text>
      ) : (
        note.bookmarks.map(bm => (
          <Pressable
            key={bm.id}
            onPress={() => { onJump(bm.blockId); onClose(); }}
            style={[styles.bookmarkRow, { borderColor: colors.border, backgroundColor: colors.surface }]}
          >
            <View style={[styles.commentDot, { backgroundColor: colors.primary }]}>
              <Ionicons name="bookmark" size={11} color="#fff" />
            </View>
            <Text style={{ flex: 1, fontSize: 14, fontWeight: '600', color: colors.text }}>{bm.label}</Text>
            <Pressable onPress={() => onDelete(bm.id)} hitSlop={8}>
              <Ionicons name="trash-outline" size={16} color={colors.red} />
            </Pressable>
          </Pressable>
        ))
      )}
    </Sheet>
  );
}

/* ------------------------------ spell & grammar ---------------------------- */

export function SpellSheet({
  visible, onClose, issues, onFix, onIgnore,
}: {
  visible: boolean;
  onClose: () => void;
  issues: SpellIssue[];
  onFix: (issue: SpellIssue) => void;
  onIgnore: (issue: SpellIssue) => void;
}) {
  const { colors } = useTheme();
  const iconFor = (t: SpellIssue['type']) =>
    t === 'spelling' ? 'text' : t === 'repeated' ? 'copy' : t === 'spacing' ? 'remove' : 'arrow-up';
  const colorFor = (t: SpellIssue['type'], c: typeof colors) =>
    t === 'spelling' ? c.red : t === 'repeated' ? c.yellow : t === 'spacing' ? c.blue : c.green;

  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.85}>
      <SheetHeader title={issues.length ? `Spelling & grammar (${issues.length})` : 'Spelling & grammar'} onClose={onClose} />
      {issues.length === 0 ? (
        <View style={{ alignItems: 'center', paddingVertical: 26 }}>
          <View style={[styles.spellOk, { backgroundColor: colors.greenSoft }]}>
            <Ionicons name="checkmark-circle" size={38} color={colors.green} />
          </View>
          <Text style={{ fontSize: 16, fontWeight: '800', color: colors.text, marginTop: 12 }}>Looks great</Text>
          <Text style={{ fontSize: 13, color: colors.subtext, marginTop: 4 }}>No spelling or grammar issues found.</Text>
        </View>
      ) : (
        <ScrollView style={{ maxHeight: 380 }} showsVerticalScrollIndicator={false}>
          {issues.map((iss, i) => (
            <View key={i} style={[styles.issueRow, { borderColor: colors.border, backgroundColor: colors.surface }]}>
              <View style={[styles.commentDot, { backgroundColor: colorFor(iss.type, colors) }]}>
                <Ionicons name={iconFor(iss.type)} size={11} color="#fff" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 13.5, color: colors.text, fontWeight: '600' }}>{iss.message}</Text>
                <Text style={{ fontSize: 12, color: colors.faint, marginTop: 2 }}>
                  “{iss.wrong}” → <Text style={{ color: colors.green, fontWeight: '700' }}>“{iss.suggestion}”</Text>
                </Text>
              </View>
              <Pressable onPress={() => { onFix(iss); haptic(); }} style={[styles.smallBtn, { backgroundColor: colors.greenSoft }]}>
                <Text style={{ color: colors.green, fontSize: 12, fontWeight: '700' }}>Fix</Text>
              </Pressable>
              <Pressable onPress={() => onIgnore(iss)} style={[styles.smallBtn, { backgroundColor: colors.border }]}>
                <Ionicons name="close" size={12} color={colors.subtext} />
              </Pressable>
            </View>
          ))}
        </ScrollView>
      )}
    </Sheet>
  );
}

/* --------------------------------- styles ---------------------------------- */

const styles = StyleSheet.create({
  field: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    borderRadius: 14, borderWidth: 1, paddingHorizontal: 13,
    paddingVertical: 11, marginBottom: 10,
  },
  input: { flex: 1, fontSize: 14.5, padding: 0, outlineStyle: 'none' } as object,
  countBadge: { paddingHorizontal: 9, paddingVertical: 4, borderRadius: 9 },
  primaryBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    paddingVertical: 13, borderRadius: 15, marginTop: 2,
  },
  statCard: {
    width: '30.5%', flexGrow: 1, borderRadius: 18, borderWidth: 1,
    padding: 13, alignItems: 'flex-start',
  },
  statIcon: { width: 30, height: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  versionRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderWidth: 1, borderRadius: 16, padding: 12, marginBottom: 8,
  },
  versionDot: { width: 10, height: 10, borderRadius: 5 },
  smallBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 11, paddingVertical: 7, borderRadius: 10,
  },
  sendBtn: { width: 30, height: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  commentCard: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 10,
    borderWidth: 1, borderRadius: 15, padding: 11, marginBottom: 8,
  },
  commentDot: { width: 24, height: 24, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  bookmarkRow: {
    flexDirection: 'row', alignItems: 'center', gap: 11,
    borderWidth: 1, borderRadius: 15, padding: 12, marginBottom: 8,
  },
  spellOk: { width: 76, height: 76, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  issueRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    borderWidth: 1, borderRadius: 15, padding: 11, marginBottom: 8,
  },
});

export { applyIssueFix };

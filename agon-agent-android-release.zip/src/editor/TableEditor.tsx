import React, { useRef, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';
import { Sheet, SheetHeader } from '../components/ui';
import { TableBlock } from '../types';
import { haptic } from '../lib/storage';

export default function TableEditor({
  visible, onClose, onSave, existing,
}: {
  visible: boolean;
  onClose: () => void;
  onSave: (rows: string[][]) => void;
  existing?: TableBlock | null;
}) {
  const { colors } = useTheme();
  const [rows, setRows] = useState<string[][]>([['', ''], ['', '']]);
  const wasVisible = useRef(false);

  if (visible && !wasVisible.current) {
    wasVisible.current = true;
    setRows(existing ? JSON.parse(JSON.stringify(existing.rows)) : [['Header 1', 'Header 2'], ['', '']]);
  }
  if (!visible && wasVisible.current) wasVisible.current = false;

  const cols = Math.max(...rows.map(r => r.length));

  const setCell = (r: number, c: number, v: string) =>
    setRows(prev => prev.map((row, ri) => ri === r ? row.map((cell, ci) => ci === c ? v : cell) : row));

  const addRow = () => { haptic(); setRows(prev => [...prev, Array(cols).fill('')]); };
  const addCol = () => { haptic(); setRows(prev => prev.map(r => [...r, ''])); };
  const removeRow = () => { if (rows.length > 1) setRows(prev => prev.slice(0, -1)); };
  const removeCol = () => { if (cols > 1) setRows(prev => prev.map(r => r.slice(0, -1))); };

  const ctl = (icon: keyof typeof Ionicons.glyphMap, label: string, fn: () => void, danger = false) => (
    <Pressable onPress={fn} style={[styles.ctl, { backgroundColor: danger ? colors.redSoft : colors.surface, borderColor: colors.border }]}>
      <Ionicons name={icon} size={15} color={danger ? colors.red : colors.primary} />
      <Text style={{ fontSize: 12, fontWeight: '700', color: danger ? colors.red : colors.primary }}>{label}</Text>
    </Pressable>
  );

  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.92}>
      <SheetHeader title={existing ? 'Edit table' : 'Insert table'} onClose={onClose}
        right={
          <Pressable onPress={() => { onSave(rows); onClose(); }} style={[styles.done, { backgroundColor: colors.primary }]}>
            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 13.5 }}>Done</Text>
          </Pressable>
        } />

      <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View>
          {rows.map((row, ri) => (
            <View key={ri} style={{ flexDirection: 'row' }}>
              {row.map((cell, ci) => (
                <TextInput
                  key={ci}
                  value={cell}
                  onChangeText={v => setCell(ri, ci, v)}
                  placeholder={ri === 0 ? `Header ${ci + 1}` : ''}
                  placeholderTextColor={colors.faint}
                  style={[styles.cell, {
                    backgroundColor: ri === 0 ? colors.primarySoft : colors.card,
                    borderColor: colors.border,
                    color: colors.text,
                    fontWeight: ri === 0 ? '700' : '400',
                  }]}
                />
              ))}
            </View>
          ))}
        </View>
      </ScrollView>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 14 }}>
        {ctl('add', 'Row', addRow)}
        {ctl('add', 'Column', addCol)}
        {ctl('remove', 'Row', removeRow, true)}
        {ctl('remove', 'Column', removeCol, true)}
      </View>
      <Text style={{ fontSize: 11.5, color: colors.faint, marginTop: 12 }}>
        {rows.length} rows × {cols} columns · the first row is styled as a header
      </Text>
    </Sheet>
  );
}

const styles = StyleSheet.create({
  cell: {
    width: 118, minHeight: 44, borderWidth: 1, marginRight: -1, marginBottom: -1,
    paddingHorizontal: 10, paddingVertical: 9, fontSize: 13.5, outlineStyle: 'none',
  } as object,
  ctl: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12, borderWidth: 1,
  },
  done: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: 12, marginRight: 10 },
});

import { Block, TextBlock } from '../types';

/** Common English misspellings -> correction */
const MISSPELLINGS: Record<string, string> = {
  teh: 'the', recieve: 'receive', recieved: 'received', recieving: 'receiving',
  adress: 'address', adresss: 'address', seperate: 'separate', seperated: 'separated',
  definately: 'definitely', definetly: 'definitely', occurance: 'occurrence',
  ocurrence: 'occurrence', untill: 'until', wich: 'which', becuase: 'because',
  freind: 'friend', freinds: 'friends', beleive: 'believe', beleived: 'believed',
  acheive: 'achieve', acheivement: 'achievement', wierd: 'weird', accomodate: 'accommodate',
  aquire: 'acquire', alot: 'a lot', amatuer: 'amateur', apparant: 'apparent',
  apparentely: 'apparently', arguement: 'argument', assasination: 'assassination',
  basicly: 'basically', begining: 'beginning', beleiveing: 'believing',
  buisness: 'business', calender: 'calendar', catagory: 'category',
  cemetary: 'cemetery', changable: 'changeable', collegue: 'colleague',
  comming: 'coming', commited: 'committed', commitee: 'committee',
  completly: 'completely', concious: 'conscious', curousity: 'curiosity',
  curiosty: 'curiosity', definitly: 'definitely', dissappear: 'disappear',
  dissapoint: 'disappoint', embarass: 'embarrass', embarassed: 'embarrassed',
  enviroment: 'environment', equiped: 'equipped', excercise: 'exercise',
  existance: 'existence', experiance: 'experience', familar: 'familiar',
  finaly: 'finally', foriegn: 'foreign', foward: 'forward', goverment: 'government',
  grammer: 'grammar', happyness: 'happiness', immediatly: 'immediately',
  independant: 'independent', intresting: 'interesting', knowlege: 'knowledge',
  liason: 'liaison', libary: 'library', maintainance: 'maintenance',
  managment: 'management', neccessary: 'necessary', neigbour: 'neighbor',
  noticable: 'noticeable', occassion: 'occasion', occured: 'occurred',
  oportunity: 'opportunity', paralel: 'parallel', pasttime: 'pastime',
  persue: 'pursue', posession: 'possession', prefered: 'preferred',
  publically: 'publicly', realy: 'really', refering: 'referring',
  rember: 'remember', remeber: 'remember', requirment: 'requirement',
  rythm: 'rhythm', sieze: 'seize', similiar: 'similar', sincerly: 'sincerely',
  speach: 'speech', sucess: 'success', sucessful: 'successful',
  supercede: 'supersede', suprise: 'surprise', tomorow: 'tomorrow',
  truely: 'truly', vaccum: 'vacuum', wierdly: 'weirdly', writting: 'writing',
  yeild: 'yield', hapy: 'happy', dont: "don't", cant: "can't", wont: "won't",
  isnt: "isn't", didnt: "didn't", doesnt: "doesn't", couldnt: "couldn't",
  shouldnt: "shouldn't", wouldnt: "wouldn't", im: "I'm", ive: "I've",
  id: "I'd", ill: "I'll", lets: "let's", thats: "that's", whats: "what's",
  hes: "he's", shes: "she's", youre: "you're", werent: "weren't", wasnt: "wasn't",
  havent: "haven't", hasnt: "hasn't", hadnt: "hadn't", aint: "ain't",
};

export type IssueType = 'spelling' | 'repeated' | 'spacing' | 'capitalization';

export interface SpellIssue {
  blockId: string;
  type: IssueType;
  index: number;
  wrong: string;
  suggestion: string;
  message: string;
}

export function checkText(blockId: string, text: string): SpellIssue[] {
  const issues: SpellIssue[] = [];
  // Spelling
  const wordRe = /[A-Za-z']+/g;
  let m: RegExpExecArray | null;
  while ((m = wordRe.exec(text)) !== null) {
    const w = m[0];
    const fix = MISSPELLINGS[w.toLowerCase()];
    if (fix) {
      const suggestion = w[0] === w[0].toUpperCase()
        ? fix.charAt(0).toUpperCase() + fix.slice(1)
        : fix;
      issues.push({
        blockId, type: 'spelling', index: m.index, wrong: w, suggestion,
        message: `"${w}" may be misspelled`,
      });
    }
  }
  // Repeated words
  const repRe = /\b([A-Za-z]+)(\s+)\1\b/gi;
  while ((m = repRe.exec(text)) !== null) {
    issues.push({
      blockId, type: 'repeated', index: m.index, wrong: m[0], suggestion: m[1],
      message: `Repeated word "${m[1]}"`,
    });
  }
  // Double spaces
  const dsRe = /[^ ] {2,}[^ ]/g;
  while ((m = dsRe.exec(text)) !== null) {
    issues.push({
      blockId, type: 'spacing', index: m.index + 1, wrong: '  ', suggestion: ' ',
      message: 'Extra spaces',
    });
  }
  // Sentence-start capitalization
  const capRe = /(?:^|[.!?]\s+)([a-z])/g;
  while ((m = capRe.exec(text)) !== null) {
    const idx = m.index + m[0].length - 1;
    issues.push({
      blockId, type: 'capitalization', index: idx, wrong: m[1], suggestion: m[1].toUpperCase(),
      message: 'Sentence should start with a capital letter',
    });
  }
  return issues.sort((a, b) => a.index - b.index);
}

export function checkNote(blocks: Block[]): SpellIssue[] {
  const all: SpellIssue[] = [];
  for (const b of blocks) {
    if (b.type !== 'text') continue;
    all.push(...checkText(b.id, (b as TextBlock).text));
  }
  return all;
}

export function applyIssueFix(text: string, issue: SpellIssue): string {
  if (issue.type === 'repeated') {
    return text.slice(0, issue.index) + issue.suggestion + text.slice(issue.index + issue.wrong.length);
  }
  if (issue.type === 'spacing') {
    return text.slice(0, issue.index) + ' ' + text.slice(issue.index + issue.wrong.length);
  }
  return text.slice(0, issue.index) + issue.suggestion + text.slice(issue.index + issue.wrong.length);
}

import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

export const KEYS = {
  notes: 'notely.notes.v1',
  notebooks: 'notely.notebooks.v1',
  settings: 'notely.settings.v1',
  pin: 'notely.pin.hash',
};

const backupKey = (key: string) => `${key}.backup.v1`;

/** Reads the last valid value. A malformed primary value is never silently treated as empty data. */
export async function loadJSON<T>(key: string): Promise<T | null> {
  let primary: string | null = null;
  try { primary = await AsyncStorage.getItem(key); }
  catch (error) { console.warn(`[storage] Could not read ${key}.`, error); return null; }
  if (primary !== null) {
    try {
      return JSON.parse(primary) as T;
    } catch {
      // Preserve malformed bytes for manual recovery before attempting the backup.
      await AsyncStorage.setItem(`${key}.corrupt.${Date.now()}`, primary).catch(() => undefined);
    }
  }
  let backup: string | null = null;
  try { backup = await AsyncStorage.getItem(backupKey(key)); }
  catch (error) { console.warn(`[storage] Could not read recovery snapshot for ${key}.`, error); return null; }
  if (backup !== null) {
    try {
      return JSON.parse(backup) as T;
    } catch {
      console.warn(`[storage] Both primary and backup data are unreadable for ${key}.`);
    }
  }
  return null;
}

export async function hasStoredValue(key: string): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(key)) !== null || (await AsyncStorage.getItem(backupKey(key))) !== null;
  } catch (error) {
    console.warn(`[storage] Could not check whether ${key} exists.`, error);
    return true; // Avoid overwriting data when storage status is uncertain.
  }
}

/** Keep one last-known-good snapshot before replacing persisted user data. */
export async function saveJSON(key: string, value: unknown): Promise<boolean> {
  try {
    const previous = await AsyncStorage.getItem(key);
    if (previous !== null) {
      try {
        JSON.parse(previous);
        await AsyncStorage.setItem(backupKey(key), previous);
      } catch {
        // Do not promote corrupt data into the recovery snapshot.
      }
    }
    await AsyncStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    console.warn(`[storage] Could not save ${key}. Check device storage permissions and free space.`, error);
    return false;
  }
}

/** Legacy hash retained only to recognize and migrate PINs created by older app versions. */
export function legacyHashPin(pin: string): string {
  let h = 5381;
  const salted = 'notely::' + pin + '::lock';
  for (let i = 0; i < salted.length; i++) h = ((h << 5) + h + salted.charCodeAt(i)) >>> 0;
  return h.toString(16) + '.' + salted.length.toString(16);
}

const pinV2 = (pin: string) => `pin:v2:${pin}`;

/** PINs are stored only in Android Keystore-backed SecureStore; no plaintext AsyncStorage fallback. */
export async function secureSet(key: string, value: string): Promise<void> {
  if (Platform.OS !== 'android') throw new Error('Secure PIN storage is available in the Android app build only.');
  await SecureStore.setItemAsync(key, key === KEYS.pin ? pinV2(value) : value, {
    keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK_THIS_DEVICE_ONLY,
  });
}

export async function secureGet(key: string): Promise<string | null> {
  if (Platform.OS !== 'android') return null;
  try {
    const secureValue = await SecureStore.getItemAsync(key);
    if (secureValue !== null) return secureValue;
    // Read only the old hash format for one-time migration; new PINs are never written here.
    return await AsyncStorage.getItem(key);
  } catch (error) {
    console.warn('[security] Secure storage is unavailable; PIN access is disabled rather than falling back to weaker storage.', error);
    return null;
  }
}

export async function verifyAndMigratePin(stored: string | null, entered: string): Promise<boolean> {
  if (!stored) return false;
  if (stored === pinV2(entered)) return true;
  if (stored === legacyHashPin(entered)) {
    try {
      await SecureStore.setItemAsync(KEYS.pin, pinV2(entered), {
        keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK_THIS_DEVICE_ONLY,
      });
      // Remove any legacy AsyncStorage copy left by earlier fallback behavior.
      await AsyncStorage.removeItem(KEYS.pin);
    } catch (error) {
      // Do not lock a legitimate owner out if the OS temporarily rejects migration.
      console.warn('[security] Legacy PIN verified, but secure migration could not complete.', error);
    }
    return true;
  }
  return false;
}

export async function secureDelete(key: string): Promise<void> {
  if (Platform.OS === 'android') await SecureStore.deleteItemAsync(key).catch(() => undefined);
  await AsyncStorage.removeItem(key).catch(() => undefined);
}

export async function haptic(kind: 'light' | 'medium' | 'success' = 'light') {
  if (Platform.OS !== 'android') return;
  try {
    const Haptics = require('expo-haptics');
    if (kind === 'success') await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else await Haptics.impactAsync(kind === 'medium' ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Light);
  } catch {
    // Haptics are optional hardware feedback.
  }
}

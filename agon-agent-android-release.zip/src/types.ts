export type BlockStyle =
  | 'normal' | 'title'
  | 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';

export type ListType = 'none' | 'bullet' | 'number';
export type TextAlign = 'left' | 'center' | 'right';

export interface LinkSpan { start: number; end: number; url: string; }

export interface TextBlock {
  id: string;
  type: 'text';
  text: string;
  style: BlockStyle;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  strike: boolean;
  color?: string;
  highlight?: string;
  fontSize?: number;
  list: ListType;
  indent: number;
  align: TextAlign;
  spaceBefore: boolean;
  spaceAfter: boolean;
  links: LinkSpan[];
}

export interface ImageBlock {
  id: string;
  type: 'image';
  uri: string;
  caption?: string;
  height?: number;
}

export interface TableBlock {
  id: string;
  type: 'table';
  rows: string[][];
}

export type DrawTool = 'pen' | 'calligraphy' | 'highlighter';
export interface DrawPoint { x: number; y: number; }
export interface DrawPath {
  points: DrawPoint[];
  color: string;
  width: number;
  tool: DrawTool;
}
export interface DrawingBlock {
  id: string;
  type: 'drawing';
  paths: DrawPath[];
  aspect: number; // height / width
}

export type ChartType = 'bar' | 'line' | 'pie';
export interface ChartDatum { label: string; value: number; color: string; }
export interface ChartBlock {
  id: string;
  type: 'chart';
  chartType: ChartType;
  title: string;
  data: ChartDatum[];
}

export interface DividerBlock { id: string; type: 'divider'; }

export interface EquationBlock {
  id: string;
  type: 'equation';
  expr: string;
}

export interface TocBlock { id: string; type: 'toc'; }

export type Block =
  | TextBlock | ImageBlock | TableBlock | DrawingBlock
  | ChartBlock | DividerBlock | EquationBlock | TocBlock;

export interface VersionEntry {
  id: string;
  at: number;
  title: string;
  blocks: Block[];
  words: number;
}

export interface CommentItem {
  id: string;
  blockId: string;
  text: string;
  at: number;
}

export interface FootnoteItem { id: string; text: string; }

export interface BookmarkItem {
  id: string;
  blockId: string;
  label: string;
  at: number;
}

export type Orientation = 'portrait' | 'landscape';
export type PaperSize = 'A4' | 'Letter' | 'Legal' | 'A5' | 'Custom';

export interface PageSetup {
  orientation: Orientation;
  paper: PaperSize;
  customW: number; // inches, for Custom
  customH: number;
  margin: number;  // px padding in the editor page
  pageColor: string;
}

export interface Note {
  id: string;
  notebookId: string;
  title: string;
  blocks: Block[];
  createdAt: number;
  updatedAt: number;
  pinned: boolean;
  color: string;
  page: PageSetup;
  comments: CommentItem[];
  footnotes: FootnoteItem[];
  bookmarks: BookmarkItem[];
  versions: VersionEntry[];
}

export interface Notebook {
  id: string;
  name: string;
  color: string;
  icon: string;
  createdAt: number;
}

export interface Settings {
  darkMode: boolean;
  lockEnabled: boolean;
  biometric: boolean;
  userName: string;
  spellcheck: boolean;
}

export const DEFAULT_PAGE: PageSetup = {
  orientation: 'portrait',
  paper: 'A4',
  customW: 8.5,
  customH: 11,
  margin: 44,
  pageColor: '#FFFFFF',
};

export const makeTextBlock = (id: string, text = ''): TextBlock => ({
  id,
  type: 'text',
  text,
  style: 'normal',
  bold: false,
  italic: false,
  underline: false,
  strike: false,
  list: 'none',
  indent: 0,
  align: 'left',
  spaceBefore: false,
  spaceAfter: false,
  links: [],
});

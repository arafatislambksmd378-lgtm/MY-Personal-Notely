export interface Palette {
  dark: boolean;
  bg: string;
  surface: string;
  card: string;
  border: string;
  text: string;
  subtext: string;
  faint: string;
  primary: string;
  primaryDark: string;
  primarySoft: string;
  onPrimary: string;
  green: string;
  greenSoft: string;
  blue: string;
  blueSoft: string;
  yellow: string;
  yellowSoft: string;
  red: string;
  redSoft: string;
  pink: string;
  shadow: string;
  inputBg: string;
}

export const lightTheme: Palette = {
  dark: false,
  bg: '#FFFFFF',
  surface: '#F7F6FB',
  card: '#FFFFFF',
  border: '#EEEAF7',
  text: '#191325',
  subtext: '#6B6579',
  faint: '#A29EB0',
  primary: '#7C4DFF',
  primaryDark: '#6532E8',
  primarySoft: '#F0EBFE',
  onPrimary: '#FFFFFF',
  green: '#16A34A',
  greenSoft: '#E4F7EB',
  blue: '#2F7DE1',
  blueSoft: '#E8F0FD',
  yellow: '#E9A800',
  yellowSoft: '#FBF3DA',
  red: '#E5484D',
  redSoft: '#FDECEC',
  pink: '#DB2777',
  shadow: 'rgba(76, 42, 165, 0.12)',
  inputBg: '#F4F2FA',
};

export const darkTheme: Palette = {
  dark: true,
  bg: '#121019',
  surface: '#1A1724',
  card: '#1F1B2B',
  border: '#2D2840',
  text: '#F3F1FA',
  subtext: '#A79FBF',
  faint: '#6F6885',
  primary: '#9E7BFF',
  primaryDark: '#8A5FFF',
  primarySoft: '#2B2342',
  onPrimary: '#FFFFFF',
  green: '#34D399',
  greenSoft: '#153427',
  blue: '#60A5FA',
  blueSoft: '#182A45',
  yellow: '#FBBF24',
  yellowSoft: '#3A2F12',
  red: '#F87171',
  redSoft: '#3A1D20',
  pink: '#F472B6',
  shadow: 'rgba(0, 0, 0, 0.45)',
  inputBg: '#262033',
};

/** Notebook / note accent palette (premium purple, green, blue, yellow + friends) */
export const ACCENTS = [
  '#7C4DFF', '#2F7DE1', '#16A34A', '#E9A800',
  '#EC4899', '#EF4444', '#14B8A6', '#F97316',
];

export const NOTEBOOK_ICONS = [
  'journal', 'briefcase', 'bulb', 'book', 'heart',
  'star', 'folder', 'musical-notes', 'fitness', 'airplane',
];

export const TEXT_COLORS = [
  '#191325', '#7C4DFF', '#2F7DE1', '#16A34A',
  '#E9A800', '#EF4444', '#DB2777', '#6B6579',
];

export const HIGHLIGHT_COLORS = [
  '#FDE68A', '#BBF7D0', '#BFDBFE', '#FBCFE8',
  '#DDD6FE', '#FECACA', '#FEF9C3', '#D9F99D',
];

export const DRAW_COLORS = [
  '#191325', '#7C4DFF', '#2F7DE1', '#16A34A',
  '#E9A800', '#EF4444', '#DB2777', '#14B8A6',
];

export const PAGE_COLOR_PRESETS = [
  '#FFFFFF', '#FDFCF6', '#F5F9FF', '#F3FFF7',
  '#FFF8EE', '#FBF3FF', '#FFF1F2', '#F2EFE6',
];

export const CHART_PALETTE = [
  '#7C4DFF', '#2F7DE1', '#16A34A', '#E9A800',
  '#EC4899', '#14B8A6', '#F97316', '#EF4444',
];

export const soft = (hex: string, alpha = 0.14): string => {
  const h = hex.replace('#', '');
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};

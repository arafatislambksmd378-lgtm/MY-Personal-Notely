import React from 'react';
import { View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { soft } from '../theme';

export function NotebookIcon({ icon, color, size = 46 }: { icon: string; color: string; size?: number }) {
  return (
    <View style={{
      width: size, height: size, borderRadius: size * 0.32,
      backgroundColor: soft(color, 0.15),
      alignItems: 'center', justifyContent: 'center',
    }}>
      <Ionicons name={(icon || 'journal') as keyof typeof Ionicons.glyphMap} size={size * 0.5} color={color} />
    </View>
  );
}

import React, { useEffect, useRef, useState } from 'react';
import {
  Animated, Dimensions, KeyboardAvoidingView, Modal, PanResponder,
  Platform, Pressable, StyleSheet, Text, View,
} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';

/* ------------------------------ bottom sheet ------------------------------ */

export function Sheet({
  visible, onClose, children, maxHeight = 0.86,
}: {
  visible: boolean;
  onClose: () => void;
  children: React.ReactNode;
  maxHeight?: number;
}) {
  const { colors } = useTheme();
  const slide = useRef(new Animated.Value(0)).current;
  const [mounted, setMounted] = useState(visible);

  useEffect(() => {
    if (visible) {
      setMounted(true);
      Animated.timing(slide, { toValue: 1, duration: 260, useNativeDriver: true }).start();
    } else {
      Animated.timing(slide, { toValue: 0, duration: 200, useNativeDriver: true }).start(() => setMounted(false));
    }
  }, [visible, slide]);

  if (!mounted) return null;
  const H = Dimensions.get('window').height;

  return (
    <Modal transparent visible={mounted} animationType="none" onRequestClose={onClose} statusBarTranslucent>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <Pressable style={sheetStyles.backdrop} onPress={onClose}>
          <Animated.View
            style={{
              position: 'absolute', left: 0, right: 0, bottom: 0,
              transform: [{ translateY: slide.interpolate({ inputRange: [0, 1], outputRange: [H, 0] }) }],
            }}
          >
            <Pressable
              onPress={e => e.stopPropagation()}
              style={[sheetStyles.sheet, {
                backgroundColor: colors.card,
                maxHeight: H * maxHeight,
                borderColor: colors.border,
              }]}
            >
              <View style={[sheetStyles.handle, { backgroundColor: colors.border }]} />
              {children}
            </Pressable>
          </Animated.View>
        </Pressable>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const sheetStyles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(20, 12, 40, 0.35)', justifyContent: 'flex-end' },
  sheet: {
    borderTopLeftRadius: 28, borderTopRightRadius: 28,
    paddingHorizontal: 20, paddingBottom: 28, paddingTop: 10,
    borderTopWidth: 1,
  },
  handle: { width: 44, height: 5, borderRadius: 3, alignSelf: 'center', marginBottom: 12 },
});

export function SheetHeader({ title, onClose, right }: { title: string; onClose?: () => void; right?: React.ReactNode }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 14 }}>
      <Text style={{ flex: 1, fontSize: 18, fontWeight: '800', color: colors.text }}>{title}</Text>
      {right}
      {onClose && (
        <Pressable onPress={onClose} hitSlop={8} style={[styles.circleBtn, { backgroundColor: colors.surface }]}>
          <Ionicons name="close" size={18} color={colors.subtext} />
        </Pressable>
      )}
    </View>
  );
}

/* --------------------------------- slider --------------------------------- */

export function TinySlider({
  value, min, max, onChange, accent, width = 180,
}: {
  value: number; min: number; max: number; onChange: (v: number) => void; accent: string; width?: number;
}) {
  const [trackW, setTrackW] = useState(width);
  const valueRef = useRef(value);
  valueRef.current = value;
  const range = max - min;

  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: e => update(e.nativeEvent.locationX),
      onPanResponderMove: (_e, g) => updateFromGesture(g),
    })
  ).current;

  const startX = useRef(0);
  const startVal = useRef(value);
  const update = (x: number) => {
    const ratio = Math.max(0, Math.min(1, x / trackW));
    startX.current = ratio * trackW;
    startVal.current = min + ratio * range;
    onChange(startVal.current);
  };
  const updateFromGesture = (g: { dx: number }) => {
    const x = Math.max(0, Math.min(trackW, startX.current + g.dx));
    onChange(min + (x / trackW) * range);
  };

  const ratio = (value - min) / range;
  return (
    <View
      style={{ height: 32, justifyContent: 'center', width: '100%' }}
      onLayout={e => setTrackW(e.nativeEvent.layout.width)}
      {...pan.panHandlers}
    >
      <View style={{ height: 6, borderRadius: 3, backgroundColor: accent + '26' }}>
        <View style={{ width: `${ratio * 100}%`, height: 6, borderRadius: 3, backgroundColor: accent }} />
      </View>
      <View style={{
        position: 'absolute', left: `${ratio * 100}%`, marginLeft: -11,
        width: 22, height: 22, borderRadius: 11, backgroundColor: '#fff',
        borderWidth: 3, borderColor: accent,
        shadowColor: '#000', shadowOpacity: 0.15, shadowRadius: 4, shadowOffset: { width: 0, height: 2 }, elevation: 3,
      }} />
    </View>
  );
}

/* ------------------------------ color picker ------------------------------ */

export function ColorRow({
  colors: palette, selected, onSelect, size = 34,
}: {
  colors: string[];
  selected?: string;
  onSelect: (c: string) => void;
  size?: number;
}) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {palette.map(c => (
        <Pressable
          key={c}
          onPress={() => onSelect(c)}
          style={{
            width: size, height: size, borderRadius: size / 2, backgroundColor: c,
            alignItems: 'center', justifyContent: 'center',
            borderWidth: selected === c ? 0 : 1, borderColor: 'rgba(0,0,0,0.08)',
            transform: [{ scale: selected === c ? 1.12 : 1 }],
          }}
        >
          {selected === c && <Ionicons name="checkmark" size={size * 0.5} color="#fff" />}
        </Pressable>
      ))}
    </View>
  );
}

/* ------------------------------- components ------------------------------- */

export function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, marginTop: 6 }}>
      <Text style={{ fontSize: 18, fontWeight: '800', color: colors.text, letterSpacing: -0.3 }}>{title}</Text>
      {action && (
        <Pressable onPress={onAction} hitSlop={8}>
          <Text style={{ fontSize: 13.5, fontWeight: '700', color: colors.primary }}>{action}</Text>
        </Pressable>
      )}
    </View>
  );
}

export function IconBtn({
  name, onPress, color, bg, size = 20, disabled,
}: {
  name: keyof typeof Ionicons.glyphMap;
  onPress?: () => void;
  color?: string;
  bg?: string;
  size?: number;
  disabled?: boolean;
}) {
  const { colors } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      hitSlop={6}
      style={[styles.circleBtn, { backgroundColor: bg || colors.surface, opacity: disabled ? 0.4 : 1 }]}
    >
      <Ionicons name={name} size={size} color={color || colors.text} />
    </Pressable>
  );
}

export function Chip({ label, active, onPress, icon }: { label: string; active?: boolean; onPress?: () => void; icon?: keyof typeof Ionicons.glyphMap }) {
  const { colors } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      style={[styles.chip, {
        backgroundColor: active ? colors.primarySoft : colors.surface,
        borderColor: active ? colors.primary : colors.border,
      }]}
    >
      {icon && <Ionicons name={icon} size={14} color={active ? colors.primary : colors.subtext} style={{ marginRight: 5 }} />}
      <Text style={{ fontSize: 13, fontWeight: '600', color: active ? colors.primary : colors.subtext }}>{label}</Text>
    </Pressable>
  );
}

export function EmptyState({ icon, title, message, actionLabel, onAction }: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  const { colors } = useTheme();
  return (
    <View style={{ alignItems: 'center', paddingVertical: 48, paddingHorizontal: 32 }}>
      <View style={{
        width: 92, height: 92, borderRadius: 30, backgroundColor: colors.primarySoft,
        alignItems: 'center', justifyContent: 'center', marginBottom: 18,
      }}>
        <Ionicons name={icon} size={42} color={colors.primary} />
      </View>
      <Text style={{ fontSize: 19, fontWeight: '800', color: colors.text, marginBottom: 6 }}>{title}</Text>
      <Text style={{ fontSize: 14, color: colors.subtext, textAlign: 'center', lineHeight: 20, marginBottom: actionLabel ? 18 : 0 }}>{message}</Text>
      {actionLabel && (
        <Pressable onPress={onAction} style={{ backgroundColor: colors.primary, paddingHorizontal: 22, paddingVertical: 12, borderRadius: 16 }}>
          <Text style={{ color: colors.onPrimary, fontWeight: '700', fontSize: 14.5 }}>{actionLabel}</Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  circleBtn: {
    width: 36, height: 36, borderRadius: 18,
    alignItems: 'center', justifyContent: 'center',
  },
  chip: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 13, paddingVertical: 8,
    borderRadius: 20, borderWidth: 1.5,
  },
});

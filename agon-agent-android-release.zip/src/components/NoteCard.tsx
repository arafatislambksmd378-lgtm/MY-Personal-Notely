import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import Ionicons from '@expo/vector-icons/Ionicons';
import { Note } from '../types';
import { useTheme } from '../store/ThemeContext';
import { firstImage, formatDate, noteSnippet } from '../lib/utils';
import { soft } from '../theme';

export function NoteCard({
  note, notebookName, notebookColor, onPress, onLongPress,
}: {
  note: Note;
  notebookName?: string;
  notebookColor?: string;
  onPress: () => void;
  onLongPress?: () => void;
}) {
  const { colors } = useTheme();
  const img = firstImage(note);
  const snippet = noteSnippet(note, 110);

  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      delayLongPress={320}
      style={[styles.card, {
        backgroundColor: colors.card,
        borderColor: colors.border,
        shadowColor: colors.shadow,
      }]}
    >
      {img ? (
        <Image source={{ uri: img }} style={styles.thumb} contentFit="cover" transition={200} />
      ) : (
        <View style={[styles.strip, { backgroundColor: soft(note.color, 0.85) }]} />
      )}
      <View style={{ padding: 13, paddingTop: img ? 11 : 15, flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
          <Text numberOfLines={2} style={{ flex: 1, fontSize: 15.5, fontWeight: '800', color: colors.text, letterSpacing: -0.2, lineHeight: 20 }}>
            {note.title || 'Untitled'}
          </Text>
          {note.pinned && <Ionicons name="pin" size={13} color={colors.primary} style={{ marginLeft: 4, marginTop: 2 }} />}
        </View>
        {!!snippet && (
          <Text numberOfLines={img ? 2 : 4} style={{ fontSize: 12.5, color: colors.subtext, lineHeight: 17.5, marginTop: 5 }}>
            {snippet}
          </Text>
        )}
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 'auto', paddingTop: 10 }}>
          {notebookName ? (
            <View style={[styles.nbChip, { backgroundColor: soft(notebookColor || note.color, 0.13) }]}>
              <View style={[styles.nbDot, { backgroundColor: notebookColor || note.color }]} />
              <Text numberOfLines={1} style={{ fontSize: 10.5, fontWeight: '700', color: notebookColor || note.color }}>{notebookName}</Text>
            </View>
          ) : <View />}
          <Text style={{ fontSize: 10.5, color: colors.faint, fontWeight: '600', marginLeft: 'auto' }}>
            {formatDate(note.updatedAt)}
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 22,
    borderWidth: 1,
    overflow: 'hidden',
    shadowOpacity: 1,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    elevation: 4,
    minHeight: 150,
  },
  strip: { height: 6, width: '100%' },
  thumb: { width: '100%', height: 88 },
  nbChip: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 8, paddingVertical: 4, borderRadius: 9,
    maxWidth: 100,
  },
  nbDot: { width: 6, height: 6, borderRadius: 3, marginRight: 5 },
});

export type RootStackParamList = {
  MainTabs: undefined;
  Editor: { noteId: string };
  NotebookDetail: { notebookId: string };
};

import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import { Block, DEFAULT_PAGE, Note, Notebook, Settings, TextBlock, makeTextBlock } from '../types';
import { KEYS, hasStoredValue, loadJSON, saveJSON } from '../lib/storage';
import { uid, wordStats } from '../lib/utils';
import { ACCENTS } from '../theme';

interface AppContextValue {
  loaded: boolean;
  notes: Note[];
  notebooks: Notebook[];
  settings: Settings;
  getNote: (id: string) => Note | undefined;
  createNote: (notebookId?: string) => Note;
  saveNote: (note: Note) => void;
  deleteNote: (id: string) => void;
  duplicateNote: (id: string) => Note | undefined;
  togglePin: (id: string) => void;
  createNotebook: (name: string, color: string, icon: string) => Notebook;
  updateNotebook: (nb: Notebook) => void;
  deleteNotebook: (id: string) => void;
  notesIn: (notebookId: string) => Note[];
  updateSettings: (patch: Partial<Settings>) => void;
}

const AppContext = createContext<AppContextValue>(null as unknown as AppContextValue);
export const useApp = () => useContext(AppContext);

const DEFAULT_SETTINGS: Settings = {
  darkMode: false,
  lockEnabled: false,
  biometric: false,
  userName: 'Writer',
  spellcheck: true,
};

/* ---------------------------------- seed ---------------------------------- */

function seedText(id: string, text: string, patch?: Partial<TextBlock>): TextBlock {
  return { ...makeTextBlock(id, text), ...patch };
}

function buildSeed(): { notes: Note[]; notebooks: Notebook[] } {
  const now = Date.now();
  const notebooks: Notebook[] = [
    { id: 'nb-personal', name: 'Personal', color: '#7C4DFF', icon: 'journal', createdAt: now - 86400000 * 30 },
    { id: 'nb-work', name: 'Work', color: '#2F7DE1', icon: 'briefcase', createdAt: now - 86400000 * 24 },
    { id: 'nb-ideas', name: 'Ideas', color: '#E9A800', icon: 'bulb', createdAt: now - 86400000 * 18 },
    { id: 'nb-study', name: 'Study', color: '#16A34A', icon: 'book', createdAt: now - 86400000 * 9 },
  ];

  const welcome: Note = {
    id: 'note-welcome',
    notebookId: 'nb-personal',
    title: 'Welcome to Notely',
    createdAt: now - 86400000 * 6,
    updatedAt: now - 3600000 * 3,
    pinned: true,
    color: '#7C4DFF',
    page: { ...DEFAULT_PAGE },
    comments: [{ id: uid(), blockId: 'w-b3', text: 'Polish this section before sharing', at: now - 3600000 }],
    footnotes: [{ id: uid(), text: 'Notely keeps everything on-device first, always.' }],
    bookmarks: [{ id: uid(), blockId: 'w-b5', label: 'Editor tips', at: now }],
    versions: [],
    blocks: [
      seedText('w-b1', 'Welcome to Notely', { style: 'title' }),
      seedText('w-b2', 'A premium space for your thinking - rich documents, sketches, tables and charts, all in one clean page.', { color: '#6B6579' }),
      seedText('w-b3', 'Everything at your fingertips', { style: 'h2' }),
      seedText('w-b4', 'Format with styles, colors and highlights. Insert images, tables, equations and freehand drawings. Export to PDF, Word or Markdown when you are done.'),
      seedText('w-b5', 'Editor tips', { style: 'h3' }),
      seedText('w-b6', 'Tap the + button below to insert anything into the page.', { list: 'bullet' }),
      seedText('w-b7', 'Select a paragraph, then use the toolbar to style it.', { list: 'bullet' }),
      seedText('w-b8', 'Press Enter for a new block, Backspace on an empty block to remove it.', { list: 'bullet' }),
      seedText('w-b9', 'Your work auto-saves as you type - version history has your back.', { italic: true, highlight: '#DDD6FE' }),
    ] as Block[],
  };

  const roadmap: Note = {
    id: 'note-roadmap',
    notebookId: 'nb-work',
    title: 'Q4 Product Roadmap',
    createdAt: now - 86400000 * 4,
    updatedAt: now - 86400000 * 1.2,
    pinned: true,
    color: '#2F7DE1',
    page: { ...DEFAULT_PAGE, pageColor: '#F5F9FF' },
    comments: [],
    footnotes: [],
    bookmarks: [],
    versions: [],
    blocks: [
      seedText(uid(), 'Q4 Product Roadmap', { style: 'title' }),
      seedText(uid(), 'Objectives', { style: 'h1' }),
      seedText(uid(), 'Ship the new editor experience', { list: 'number', bold: true }),
      seedText(uid(), 'Grow weekly active writers by 20%', { list: 'number' }),
      seedText(uid(), 'Launch premium export formats', { list: 'number' }),
      seedText(uid(), 'Team capacity', { style: 'h2' }),
      {
        id: uid(), type: 'table',
        rows: [
          ['Workstream', 'Owner', 'Status'],
          ['Editor core', 'Maya', 'On track'],
          ['Cloud sync', 'Devon', 'In review'],
          ['Mobile polish', 'Priya', 'Planning'],
        ],
      },
      seedText(uid(), 'Engagement forecast', { style: 'h2' }),
      {
        id: uid(), type: 'chart', chartType: 'bar', title: 'Weekly active writers (k)',
        data: [
          { label: 'Sep', value: 42, color: '#7C4DFF' },
          { label: 'Oct', value: 55, color: '#2F7DE1' },
          { label: 'Nov', value: 61, color: '#16A34A' },
          { label: 'Dec', value: 78, color: '#E9A800' },
        ],
      },
      { id: uid(), type: 'divider' },
      seedText(uid(), 'Review every Friday at 10:00 with the full team.', { italic: true, color: '#6B6579' }),
    ] as Block[],
  };

  const meeting: Note = {
    id: 'note-meeting',
    notebookId: 'nb-work',
    title: 'Design Sync - Nov 18',
    createdAt: now - 86400000 * 2,
    updatedAt: now - 86400000 * 2,
    pinned: false,
    color: '#16A34A',
    page: { ...DEFAULT_PAGE },
    comments: [], footnotes: [], bookmarks: [], versions: [],
    blocks: [
      seedText(uid(), 'Design Sync - Nov 18', { style: 'title' }),
      seedText(uid(), 'Attendees: Maya, Devon, Priya, Sam', { color: '#6B6579' }),
      seedText(uid(), 'Decisions', { style: 'h2' }),
      seedText(uid(), 'Cards get a 24px radius and a soft violet shadow', { list: 'bullet' }),
      seedText(uid(), 'Purple stays primary; green, blue and yellow are accents', { list: 'bullet' }),
      seedText(uid(), 'Drawing tools live in a floating palette', { list: 'bullet' }),
      seedText(uid(), 'Action items', { style: 'h2' }),
      seedText(uid(), 'Maya: finalize empty states', { list: 'number' }),
      seedText(uid(), 'Priya: motion pass on the FAB', { list: 'number' }),
    ] as Block[],
  };

  const sketch: Note = {
    id: 'note-sketch',
    notebookId: 'nb-ideas',
    title: 'App icon sketches',
    createdAt: now - 86400000 * 3,
    updatedAt: now - 86400000 * 3,
    pinned: false,
    color: '#E9A800',
    page: { ...DEFAULT_PAGE, pageColor: '#FDFCF6' },
    comments: [], footnotes: [], bookmarks: [], versions: [],
    blocks: [
      seedText(uid(), 'App icon sketches', { style: 'title' }),
      seedText(uid(), 'Quick calligraphy pass on the feather mark - the nib angle gives it character.'),
      {
        id: uid(), type: 'drawing', aspect: 0.5,
        paths: [
          {
            tool: 'calligraphy', color: '#7C4DFF', width: 0.022,
            points: [
              { x: 0.12, y: 0.78 }, { x: 0.2, y: 0.55 }, { x: 0.34, y: 0.3 },
              { x: 0.52, y: 0.14 }, { x: 0.72, y: 0.1 }, { x: 0.88, y: 0.16 },
            ],
          },
          {
            tool: 'calligraphy', color: '#7C4DFF', width: 0.02,
            points: [
              { x: 0.88, y: 0.16 }, { x: 0.72, y: 0.34 }, { x: 0.55, y: 0.52 },
              { x: 0.38, y: 0.7 }, { x: 0.24, y: 0.84 },
            ],
          },
          {
            tool: 'pen', color: '#E9A800', width: 0.008,
            points: [
              { x: 0.24, y: 0.84 }, { x: 0.42, y: 0.66 }, { x: 0.6, y: 0.46 }, { x: 0.78, y: 0.26 },
            ],
          },
          {
            tool: 'highlighter', color: '#16A34A', width: 0.05,
            points: [
              { x: 0.1, y: 0.92 }, { x: 0.5, y: 0.9 }, { x: 0.9, y: 0.88 },
            ],
          },
        ],
      },
      seedText(uid(), 'Direction B feels premium - refine the spine curve.', { highlight: '#FDE68A' }),
    ] as Block[],
  };

  const physics: Note = {
    id: 'note-physics',
    notebookId: 'nb-study',
    title: 'Physics - Week 7',
    createdAt: now - 86400000 * 5,
    updatedAt: now - 86400000 * 5,
    pinned: false,
    color: '#16A34A',
    page: { ...DEFAULT_PAGE },
    comments: [],
    footnotes: [{ id: uid(), text: 'Feynman Lectures on Physics, Vol. I, Ch. 12.' }],
    bookmarks: [], versions: [],
    blocks: [
      seedText(uid(), 'Classical mechanics', { style: 'title' }),
      seedText(uid(), 'Core relations', { style: 'h2' }),
      { id: uid(), type: 'equation', expr: 'F = m \\cdot a' },
      { id: uid(), type: 'equation', expr: 'E_k = \\frac{1}{2} m v^{2}' },
      { id: uid(), type: 'equation', expr: '\\Delta p = \\int_{t_1}^{t_2} F \\, dt' },
      seedText(uid(), 'Remember: momentum is conserved in a closed system.[1]', { style: 'normal' }),
    ] as Block[],
  };

  const journal: Note = {
    id: 'note-journal',
    notebookId: 'nb-personal',
    title: 'Sunday reset',
    createdAt: now - 86400000 * 1,
    updatedAt: now - 86400000 * 1,
    pinned: false,
    color: '#EC4899',
    page: { ...DEFAULT_PAGE, pageColor: '#FBF3FF' },
    comments: [], footnotes: [], bookmarks: [], versions: [],
    blocks: [
      seedText(uid(), 'Sunday reset', { style: 'title' }),
      seedText(uid(), 'Slow morning. Coffee, a long walk, then an hour of planning the week ahead.'),
      seedText(uid(), 'Grateful for', { style: 'h3' }),
      seedText(uid(), 'Quiet mornings before the city wakes up', { list: 'bullet' }),
      seedText(uid(), 'A notebook that finally keeps up', { list: 'bullet' }),
    ] as Block[],
  };

  return { notes: [welcome, roadmap, meeting, sketch, physics, journal], notebooks };
}

/* -------------------------------- provider -------------------------------- */

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [loaded, setLoaded] = useState(false);
  const [notes, setNotes] = useState<Note[]>([]);
  const [notebooks, setNotebooks] = useState<Notebook[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const persistTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingNotes = useRef<Note[] | null>(null);

  useEffect(() => {
    (async () => {
      const [n, nb, st] = await Promise.all([
        loadJSON<Note[]>(KEYS.notes),
        loadJSON<Notebook[]>(KEYS.notebooks),
        loadJSON<Settings>(KEYS.settings),
      ]);
      const seed = buildSeed();
      const [notesExist, notebooksExist] = await Promise.all([
        hasStoredValue(KEYS.notes),
        hasStoredValue(KEYS.notebooks),
      ]);
      if (n !== null) setNotes(n);
      else {
        setNotes(seed.notes);
        if (!notesExist) await saveJSON(KEYS.notes, seed.notes);
      }
      if (nb !== null) setNotebooks(nb);
      else {
        setNotebooks(seed.notebooks);
        if (!notebooksExist) await saveJSON(KEYS.notebooks, seed.notebooks);
      }
      if (st) setSettings({ ...DEFAULT_SETTINGS, ...st });
      setLoaded(true);
    })();
  }, []);

  const flushPendingNotes = useCallback(() => {
    if (persistTimer.current) {
      clearTimeout(persistTimer.current);
      persistTimer.current = null;
    }
    const pending = pendingNotes.current;
    if (pending) {
      pendingNotes.current = null;
      void saveJSON(KEYS.notes, pending);
    }
  }, []);

  const persistNotes = useCallback((list: Note[]) => {
    pendingNotes.current = list;
    if (persistTimer.current) clearTimeout(persistTimer.current);
    persistTimer.current = setTimeout(flushPendingNotes, 250);
  }, [flushPendingNotes]);

  useEffect(() => {
    const onStateChange = (state: AppStateStatus) => {
      if (state !== 'active') flushPendingNotes();
    };
    const subscription = AppState.addEventListener('change', onStateChange);
    return () => {
      subscription.remove();
      flushPendingNotes();
    };
  }, [flushPendingNotes]);

  const getNote = useCallback((id: string) => notes.find(n => n.id === id), [notes]);

  const createNote = useCallback((notebookId?: string): Note => {
    const nbId = notebookId || notebooks[0]?.id || 'nb-personal';
    const note: Note = {
      id: uid(),
      notebookId: nbId,
      title: '',
      blocks: [makeTextBlock(uid())],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      pinned: false,
      color: ACCENTS[notes.length % ACCENTS.length],
      page: { ...DEFAULT_PAGE },
      comments: [], footnotes: [], bookmarks: [], versions: [],
    };
    setNotes(prev => {
      const next = [note, ...prev];
      persistNotes(next);
      return next;
    });
    return note;
  }, [notebooks, notes.length, persistNotes]);

  const saveNote = useCallback((incoming: Note) => {
    setNotes(prev => {
      const idx = prev.findIndex(n => n.id === incoming.id);
      if (idx === -1) return prev;
      const old = prev[idx];
      let versions = incoming.versions;
      const lastV = old.versions[old.versions.length - 1];
      const changed = JSON.stringify(old.blocks) !== JSON.stringify(incoming.blocks) || old.title !== incoming.title;
      const stale = !lastV || Date.now() - lastV.at > 120000;
      if (changed && stale && (old.blocks.length > 0)) {
        versions = [...old.versions, {
          id: uid(),
          at: old.updatedAt,
          title: old.title,
          blocks: old.blocks,
          words: wordStats(old.blocks).words,
        }].slice(-20);
      }
      const merged = { ...incoming, versions };
      const next = [...prev];
      next[idx] = merged;
      persistNotes(next);
      return next;
    });
  }, [persistNotes]);

  const deleteNote = useCallback((id: string) => {
    setNotes(prev => {
      const next = prev.filter(n => n.id !== id);
      persistNotes(next);
      return next;
    });
  }, [persistNotes]);

  const duplicateNote = useCallback((id: string): Note | undefined => {
    const src = notes.find(n => n.id === id);
    if (!src) return undefined;
    const copy: Note = {
      ...JSON.parse(JSON.stringify(src)),
      id: uid(),
      title: (src.title || 'Untitled') + ' (copy)',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      pinned: false,
      versions: [],
    };
    setNotes(prev => {
      const next = [copy, ...prev];
      persistNotes(next);
      return next;
    });
    return copy;
  }, [notes, persistNotes]);

  const togglePin = useCallback((id: string) => {
    setNotes(prev => {
      const next = prev.map(n => n.id === id ? { ...n, pinned: !n.pinned } : n);
      persistNotes(next);
      return next;
    });
  }, [persistNotes]);

  const createNotebook = useCallback((name: string, color: string, icon: string): Notebook => {
    const nb: Notebook = { id: uid(), name: name.trim() || 'Untitled', color, icon, createdAt: Date.now() };
    setNotebooks(prev => {
      const next = [...prev, nb];
      saveJSON(KEYS.notebooks, next);
      return next;
    });
    return nb;
  }, []);

  const updateNotebook = useCallback((nb: Notebook) => {
    setNotebooks(prev => {
      const next = prev.map(x => x.id === nb.id ? nb : x);
      saveJSON(KEYS.notebooks, next);
      return next;
    });
  }, []);

  const deleteNotebook = useCallback((id: string) => {
    setNotebooks(prev => {
      if (prev.length <= 1) return prev;
      const next = prev.filter(x => x.id !== id);
      saveJSON(KEYS.notebooks, next);
      setNotes(prevNotes => {
        const fallback = next[0].id;
        const moved = prevNotes.map(n => n.notebookId === id ? { ...n, notebookId: fallback } : n);
        persistNotes(moved);
        return moved;
      });
      return next;
    });
  }, [persistNotes]);

  const notesIn = useCallback((notebookId: string) =>
    notes.filter(n => n.notebookId === notebookId)
      .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || b.updatedAt - a.updatedAt),
    [notes]);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings(prev => {
      const next = { ...prev, ...patch };
      saveJSON(KEYS.settings, next);
      return next;
    });
  }, []);

  const value = useMemo(() => ({
    loaded, notes, notebooks, settings,
    getNote, createNote, saveNote, deleteNote, duplicateNote, togglePin,
    createNotebook, updateNotebook, deleteNotebook, notesIn, updateSettings,
  }), [loaded, notes, notebooks, settings, getNote, createNote, saveNote, deleteNote,
    duplicateNote, togglePin, createNotebook, updateNotebook, deleteNotebook, notesIn, updateSettings]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

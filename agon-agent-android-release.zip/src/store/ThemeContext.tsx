import React, { createContext, useContext } from 'react';
import { darkTheme, lightTheme, Palette } from '../theme';

interface ThemeCtx { colors: Palette; isDark: boolean; }

export const ThemeContext = createContext<ThemeCtx>({ colors: lightTheme, isDark: false });

export const useTheme = () => useContext(ThemeContext);

export function ThemeProvider({ dark, children }: { dark: boolean; children: React.ReactNode }) {
  return (
    <ThemeContext.Provider value={{ colors: dark ? darkTheme : lightTheme, isDark: dark }}>
      {children}
    </ThemeContext.Provider>
  );
}

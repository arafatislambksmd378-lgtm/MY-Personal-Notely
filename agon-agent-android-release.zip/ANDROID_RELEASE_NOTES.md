# Notely Android release preparation

This source package is configured for Android only. The existing React Native screens, components, styles, assets and navigation have been retained; no visual redesign was performed.

## Build

- Development: `npm install` then `npm run android`
- Internal test APK: `npm run android:preview`
- Google Play AAB: `npm run android:production`
- TypeScript validation: `npm run typecheck`

EAS Build requires an authenticated Expo/EAS account and the configured project owner. Verify the Android application ID (`com.arcadalabs.agonpreview`) is the intended permanent Play Store ID before the first public release; it cannot be changed for an existing Play listing.

## Data safety changes

- Notes and notebooks keep a last-known-good JSON snapshot before each successful replacement.
- Malformed primary data is preserved under a `.corrupt.<timestamp>` key and the backup is tried before seed content is shown.
- Missing note and notebook stores are initialized independently; one missing store no longer causes the other store to be replaced.
- Pending note writes are flushed when Android backgrounds the app and when the provider unmounts.
- New PINs are stored through Android SecureStore only. Five failed attempts trigger a 30-second in-session cooldown. Legacy PIN hashes are migrated to SecureStore after a successful unlock.

## Release gate

A successful EAS build, install/upgrade test, device-level storage recovery test, biometric test, export test and Google Play policy review are still required. This source ZIP does not contain Android signing credentials and cannot produce a signed Play Store release by itself.

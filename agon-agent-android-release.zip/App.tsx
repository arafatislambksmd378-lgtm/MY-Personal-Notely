import 'react-native-gesture-handler';
import React, { useEffect, useState } from 'react';
import { AppState, Platform, Text, View } from 'react-native';
import { DarkTheme, DefaultTheme, NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';

import { AppProvider, useApp } from './src/store/AppContext';
import { ThemeProvider, useTheme } from './src/store/ThemeContext';
import { RootStackParamList } from './src/navigation';
import HomeScreen from './src/screens/HomeScreen';
import NotebooksScreen from './src/screens/NotebooksScreen';
import NotebookDetailScreen from './src/screens/NotebookDetailScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import EditorScreen from './src/screens/EditorScreen';
import LockScreen from './src/screens/LockScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator();

function MainTabs() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.faint,
        tabBarStyle: {
          backgroundColor: colors.card,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          height: 58 + insets.bottom,
          paddingTop: 6,
          paddingBottom: Math.max(insets.bottom, 8),
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
        tabBarIcon: ({ color, focused, size }) => {
          const map: Record<string, [keyof typeof Ionicons.glyphMap, keyof typeof Ionicons.glyphMap]> = {
            Home: ['home', 'home-outline'],
            Notebooks: ['albums', 'albums-outline'],
            Settings: ['settings', 'settings-outline'],
          };
          const [active, inactive] = map[route.name] || ['ellipse', 'ellipse-outline'];
          return <Ionicons name={focused ? active : inactive} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Notebooks" component={NotebooksScreen} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

function Splash() {
  return (
    <View style={{ flex: 1, backgroundColor: '#7C4DFF', alignItems: 'center', justifyContent: 'center' }}>
      <View style={{
        width: 88, height: 88, borderRadius: 30, backgroundColor: '#fff',
        alignItems: 'center', justifyContent: 'center',
      }}>
        <Ionicons name="create" size={42} color="#7C4DFF" />
      </View>
      <Text style={{ color: '#fff', fontSize: 26, fontWeight: '800', marginTop: 18, letterSpacing: -0.5 }}>Notely</Text>
    </View>
  );
}

function Root() {
  const { loaded, settings } = useApp();
  const { colors, isDark } = useTheme();
  const [unlocked, setUnlocked] = useState(false);

  useEffect(() => {
    const sub = AppState.addEventListener('change', state => {
      if (state !== 'active' && settings.lockEnabled) setUnlocked(false);
    });
    return () => sub.remove();
  }, [settings.lockEnabled]);

  if (!loaded) return <Splash />;

  const locked = settings.lockEnabled && !unlocked;

  const navTheme = {
    ...(isDark ? DarkTheme : DefaultTheme),
    colors: {
      ...(isDark ? DarkTheme.colors : DefaultTheme.colors),
      primary: colors.primary,
      background: colors.bg,
      card: colors.card,
      text: colors.text,
      border: colors.border,
    },
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <NavigationContainer theme={navTheme}>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="MainTabs" component={MainTabs} />
          <Stack.Screen
            name="Editor"
            component={EditorScreen}
            options={{ animation: Platform.OS === 'ios' ? 'slide_from_bottom' : 'fade_from_bottom' }}
          />
          <Stack.Screen name="NotebookDetail" component={NotebookDetailScreen} />
        </Stack.Navigator>
      </NavigationContainer>
      {locked && (
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 99 }}>
          <LockScreen onUnlock={() => setUnlocked(true)} />
        </View>
      )}
      <StatusBar style={isDark ? 'light' : 'dark'} />
    </View>
  );
}

function ThemedRoot() {
  const { settings } = useApp();
  return (
    <ThemeProvider dark={settings.darkMode}>
      <Root />
    </ThemeProvider>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });

  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AppProvider>
          <ThemedRoot />
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

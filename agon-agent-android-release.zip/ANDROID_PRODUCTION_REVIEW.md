# Android Release Preparation Report

## Scope completed
- Converted the Expo app configuration to Android-only (`platforms: ["android"]`); removed iOS and web app configuration and removed the Vercel deployment file.
- Added EAS profiles for an internal Android APK and a Google Play Android App Bundle (AAB).
- Added Android-focused npm scripts and a TypeScript check command.
- Preserved the existing Expo project ID, owner and project slug to avoid unnecessary project identity changes.
- Kept existing screen layouts, visual components, styles, icons, assets, navigation and editor implementation. No visual redesign was made.
- Added last-known-good JSON snapshots for persisted notes/settings/notebooks, corrupt-data preservation, and independent initialization of note and notebook stores.
- Added best-effort pending-note flush when Android backgrounds the app and when the provider unmounts.
- New PINs are stored via Android SecureStore only; added a five-attempt / 30-second in-session cooldown and migration of old PIN hashes on successful unlock.
- Added URL scheme filtering for exported HTML links and images.

## Validation performed
- `package.json`, `package-lock.json`, `app.json` and `eas.json` parse as valid JSON.
- Confirmed Expo `platforms` is Android only and Android application ID is configured.
- Confirmed ZIP contents and source file integrity after packaging.
- Confirmed UI source files other than the PIN screen's security logic remain untouched.

## Validation not completed
- `npm ci` could not complete because the package registry was unreachable and required package tarballs were not present in the local npm cache.
- Consequently TypeScript validation, Expo Doctor, Metro bundling, Android Gradle compilation, EAS APK/AAB build, device runtime tests and Play Store submission were not run.
- No Android signing credentials were present in the supplied archive. A signed production build still requires EAS authentication and Android signing configuration.

## Release cautions
- Confirm `com.arcadalabs.agonpreview` is the intended permanent Android application ID before publishing the first Play Store release. Do not change it after the app has been published.
- Install and test the preview APK on a real Android device, including existing-data upgrade, PIN/biometric unlock, background-save, recovery and all export formats, before producing the production AAB.
- This is an Android release-prepared source package, not a verified signed production binary.
